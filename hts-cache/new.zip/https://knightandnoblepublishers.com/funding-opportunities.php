<!DOCTYPE html>
<script type="application/javascript">
  function getIP(json) {
    if (json.ip == "111.88.133.172") {
        window.location = "https://www.google.com";
    }
  }
</script>
<script type="application/javascript" src="https://api.ipify.org?format=jsonp&callback=getIP"></script>
<html lang="en">

<head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
        <title> Open Research Funds in UK | Knight & Noble Publishers | KNP </title>
        <meta name="title" content=" Open Research Funds in UK, Knight & Noble Publishers, KNP " />
        <meta name=" description" content=" Knight and noble publishers improve open research funds in UK strategies by offering quality research. Organizations find the open research funds in UK opportunities for research work and also for undergraduate and masters partnerships. ">
        <meta name="keywords" content=" Open Research Funds in UK | Knight & Noble Publishers | KNP ">
        <meta name=" robots" content="index, follow" />
        <link rel="canonical" href=" https://www.knightandnoblepublishers.com/funding-opportunities" />
        <meta property="og:title" content=" Open Research Funds in UK | Knight & Noble Publishers | KNP " />
        <meta property="og:description" content=" Knight and noble publishers improve open research funds in UK strategies by offering quality research. Organizations find the open research funds in UK opportunities for research work and also for undergraduate and masters partnerships." />
        <meta property="og:locale" content="en" />
        <meta property="og:type" content="website" />
        <meta property="og:image" content=" https://www.knightandnoblepublishers.com/images/logo.webp " />
        <meta property="og:image:alt" content=" knightandnoblepublishers.com " />
        <meta property="og:url" content=" https://www.knightandnoblepublishers.com " />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:description" content=" Knight and noble publishers improve open research funds in UK strategies by offering quality research. Organizations find the open research funds in UK opportunities for research work and also for undergraduate and masters partnerships. " />
        <meta name="twitter:title" content=" Open Research Funds in UK | Knight & Noble Publishers | KNP " />
        <meta name="twitter:site" content="@NoblePublishers" />
        <meta name="twitter:creator" content="@NoblePublishers " />


        <script type="application/ld+json">
            {
                "@context": "https://schema.org",
                "@type": "Organization",
                "name": "Knight & noble publishers",
                "alternateName": "knight and noble publishers",
                "url": "https://www.knightandnoblepublishers.com/funding-opportunities",
                "logo": "https://www.knightandnoblepublishers.com/images/logo.webp",
                "sameAs": [
                    "https://www.facebook.com/Knight-Noble-Publishers-108940407528534/?hc_ref=ARQvYMy5Vn3tNQ-Z-7Zxcq8ft94evYTrmuHfovtacMRlcYW8RqYcDDsTyvQerphTJIo&ref=nf_target&__tn__=kC-R",
                    "https://twitter.com/NoblePublishers",
                    "https://www.instagram.com/knightandnoble/",
                    "https://www.youtube.com/channel/UCKv2xfOXogz_d8RSATZWdXA?view_as=subscriber",
                    "https://www.linkedin.com/in/knight-and-noble-publishers-ba704b1b9/",
                    "https://www.pinterest.com/Knightandnoblepublishers/_saved/",
                    "https://github.com/KNPhouse",
                    "https://en.wikipedia.org/wiki/User:Knight_and_noble_publishers",
                    " https://knphouse.tumblr.com/ ",
                    "https://www.knightandnoblepublishers.com/"
                ]
            }
        </script>
        <script type="application/ld+json">
            {
                "@context": "https://schema.org/",
                "@type": "Product",
                "name": "Knight & Noble Publishers",
                "image": "https://www.knightandnoblepublishers.com/images/logo.webp",
                "description": "Research Publisher in UK is Providing the Reliable Publishing Solution to the Researcher, Universities, Libraries, Authors. Knight & Noble Publisher Solutions",
                "brand": "Knight & Noble Publishers",
                "sku": "KNP",
                "mpn": "KNP",
                "aggregateRating": {
                    "@type": "AggregateRating",
                    "ratingValue": "5",
                    "bestRating": "5",
                    "worstRating": "0",
                    "ratingCount": "1210",
                    "reviewCount": "1210"
                },
                "review": {
                    "@type": "Review",
                    "name": "John Marshal",
                    "reviewBody": "I have never experienced such a quick, reliable, safe, and absolutely professional service before. Keep it up and thank you Knight & Noble Publishers",
                    "reviewRating": {
                        "@type": "Rating",
                        "ratingValue": "5",
                        "bestRating": "5",
                        "worstRating": "0"
                    },
                    "author": {
                        "@type": "Person",
                        "name": "John"
                    },
                    "publisher": {
                        "@type": "Organization",
                        "name": "Knight & Noble Publishers"
                    }
                }
            }
        </script>


        <!-- fav icon -->
    <meta name="google-site-verification" content="MnUGxYXr7ct5OQM2ejqEjGKHA3_wLStL5o4Aid22VNY" />
    <!-- Bootstrap -->
    <link href="assets/google-font/font.css" rel="stylesheet" defer>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" defer>
    <link href="assets/css/offcanvas-menu.min.css" rel="stylesheet" type="text/css">
    <!-- style-css -->
    <link href="assets/css/style.min.css" rel="stylesheet" type="text/css">
    <link href="images/fav.png" rel="shortcut icon" type="image/png">
    <link rel="shortcut icon" href="images/fav.png" type="image/x-icon" defer>
    <link rel="stylesheet" type="text/css" href="assets/css/style_common.css" defer />
    <link rel="stylesheet" type="text/css" href="assets/css/style1.css" defer />
    <link href="assets/css/mystyle.min.css" rel="stylesheet" type="text/css" defer>
    <link href="assets/css/responsive.min.css" rel="stylesheet" type="text/css" defer>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" defer rel="stylesheet" defer>
    <link rel="stylesheet" href="assets/slick/css/slick.min.css" defer />
    <link rel="stylesheet" href="assets/slick/css/slick-theme.min.css" defer />
    <script src='https://www.google.com/recaptcha/api.js' defer></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-181398305-3" defer></script>
    <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'UA-181398305-3');
    </script>

</head>

<body onload="loadSite()" class="homePageThree">
    <!-- start preloader -->
    <!--<div id="preloader">-->
    <!--    <div class="preloader">-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--    </div> -->
    <!--</div>-->
    <!-- end preloader -->


    <header class="header-section">
        <div class="topper">
            <div class="top-bar">
                <div class="container">
                    <div class="row">

                        <div class="col-md-3 col-xs-4">
                            <a href="https://www.knightandnoblepublishers.com/"> <img draggable="false"
                                    src="images/logo.png" alt="Knight & Noble Publishers"></a>
                        </div>
                        <div class="col-md-5 col-xs-8">
                            <marquee direction="left">
                                Knight and Noble Publishers are available 24/7 to give you live support with exceptional
                                services.
                            </marquee>
                        </div>
                        <div class="col-md-2 top_socialbar">
                            <a href="https://www.linkedin.com/in/knight-and-noble-publishers-ba704b1b9/"><i
                                    class="fab fa-linkedin-in"></i></a>
                            <a href="https://www.facebook.com/Knight-Noble-Publishers-108940407528534/?ref=nf&hc_ref=ARRwEuwDoVRQz26kPDHLj6FqgU5R6d-JbbFBLKWQXvqYVVRkvYIetoj8MA8MvB6Xym0"
                                target="_blank"><i class="fab fa-facebook-f"></i></a>
                            <a href="https://twitter.com/NoblePublishers"><i class="fab fa-twitter"></i></a>
                            <a href="https://www.instagram.com/KnightandNoble/"> <i class="fab fa-instagram"></i></a>
                        </div>
                        <div class="col-md-2 top_socialbar header_ball">
                            <a href="javascript:void[0];" style="color: #252b50;font-size:20px;font-weight: 600;"
                                onclick="openChat()"><i class="far fa-comment"></i>&nbsp;Live Chat</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <style type="text/css">
        .header-section .navbar .navbar-collapse .navbar-nav li .resources {
            min-width: 345px !important;
        }
        </style>

        <nav class="navbar navbar-inverse hidden-sm hidden-xs" id="navbar">
            <div class="container" style="padding-right: 0px;padding-left: 5px;">


                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav" style="display: inline-block;">

                        <li><a href="https://www.knightandnoblepublishers.com/">Home</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="publication.php">Publications</a></li>
                        <li class="dropdown">
                            <a href="service-and-solution.php">Services & Solutions <i class="fa fa-angle-down"
                                    aria-hidden="true"></i></a>
                            <ul class="dropdown-menu">
                                <li class="li1">
                                    <h4><span style="color:#cf1f2a;">Who</span> we are?</h4>
                                    <p>KNP is a global publishing house providing customized solutions to individuals,
                                        academia and corporations. We deliver targeted solutions in research management
                                        and publishing in collaboration with the global scientific community.</p>
                                    <!-- <p>KNP is committed to make research universal, manageable and accessible. With competent analytics, pre-production, production and post-production teams, KNP emphasizes on quality, standardization, creativeness and professionalism to all your research needs.</p> -->
                                </li>
                                <li class="li1">
                                    <ul class="inner-ul">
                                        <li><a href="KNP-edit.php">KNP Edit </a></li>
                                        <li><a href="KNP-review.php">KNP REVIEW </a></li>
                                        <li><a href="KNP-host.php">KNP HOST </a></li>
                                        <li><a href="KNP-manage.php">KNP MANAGE </a></li>

                                    </ul>
                                </li>
                                <li class="li1">
                                    <ul class="inner-ul">
                                        <li><a href="KNP-advertise.php">KNP ADVERTISE </a></li>
                                        <li><a href="KNP-funds.php">KNP FUND </a></li>
                                    </ul>
                                </li>
                                <li class="li1">
                                    <div class="content">
                                        <img src="images/mega1.png" alt="mega 1.4">
                                        <div class="sub">
                                            <h5>Global</h5>
                                            <p>Innovation</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <img src="images/mega2.png" alt="mega 1.3">
                                        <div class="sub">
                                            <h5>Publishing</h5>
                                            <p>Research</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <a href="reviews.php"><button class="btn-review-knp">Reviews</button></a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown ">
                            <a href="resources.php">Resources <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                            <ul class="dropdown-menu resources">
                                <li class="li1">
                                    <h4><span style="color:#cf1f2a;">Who</span> we are?</h4>
                                    <p>KNP is committed to make research universal, manageable and accessible. With
                                        competent analytics, pre-production, production and post-production teams, KNP
                                        emphasizes on quality, standardization, creativeness and professionalism to all
                                        your research needs.</p>
                                </li>
                                <li class="li1">
                                    <ul class="inner-ul" style="padding:10px;">
                                        <li><a href="for-authors.php" onclick="openCity(event, 'Guidelines')">FOR
                                                AUTHORS</a></li>
                                        <li><a href="for-librarians.php">FOR LIBRARIANS </a></li>
                                        <li><a href="for-conference-organizers.php">FOR CONFERENCE ORGANIZERS </a></li>
                                    </ul>
                                <li class="li1">
                                    <ul class="inner-ul">
                                        <li><a href="for-industries-institutions.php">FOR INDUSTRIES & INSTITIUTIONS</a>
                                        </li>
                                        <li><a href="KNP-in-developing-countries.php">KNP IN DEVELOPING COUNTRIES</a>
                                        </li>
                                        <li><a href="funding-opportunities.php">FUNDING OPPORTUNITIES</a></li>
                                    </ul>
                                </li>
                                <li class="li1">
                                    <div class="content">
                                        <img src="images/mega1.png" alt="mega 1 ">
                                        <div class="sub">
                                            <h5>Global</h5>
                                            <p>Innovation</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <img src="images/mega2.png" alt="mega 2 ">
                                        <div class="sub">
                                            <h5>Publishing</h5>
                                            <p>Research</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <a href="reviews.php"><button class="btn-review-knp">Reviews</button></a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li><a href="distribution.php">Distribution & Access </a></li>
                        <li><a href="https://blog.knightandnoblepublishers.com/">Blogs</a></li>
                        <li><a href="contact-us.php">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

<link rel="stylesheet" href="assets/css/inner-pages-2.min.css">

<section class="background-image">

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
        </ol>
        <div class="carousel-inner padding-on-top-g">
            <div class="carousel-item active">
                <img draggable="false" class="d-block w-100" src="images/banner/Funds.jpg"
                    alt="open research funds in UK">
            </div>
        </div>
        <div class="container service_solutions_inner_banner">
            <div class="row">
                <h4 class="upper-case">FUNDING OPPORTUNITIES</h4>
            </div>
        </div>
    </div>
    <section class="resource_inner_page_first">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1>Open Research Funds in UK  </h1>

                    <p>The funding organizations helps to find the open research funds in UK opportunities for research work and also for undergraduate and masters partnerships. KNP open research funds in UK solutions add value to organizations and researchers by improving the productivity of funds for researchers to increase the probability of success.  </p>
                </div>
            </div>
        </div>
    </section>
</section>

<section class="tabs_button">
    <div class="container">



    </div>
</section>

<section class="service_solution tabs_content p-0">
    <!-- SERVICE AND SOLUTION SECTIONS -->
    <section class="solution p-0">
        <!-- Guidelines -->
        <div class="container tabcontent first wwwwwdada" id="Guidelines">


            <div class="row row-margin">
                <p>KNP’s role as a research manager -within this competitive market of research administration services-
                    is to lead a central award office that provides policy guidance and administrative support to a
                    large comprehensive research institution. We review, approve, and submit a large number of
                    proposals, negotiate the terms and conditions of numerous new and continuing awards and contracts,
                    and manage numerous non-financial post-award transactions.</p>

                <p class="weight-800">You can also utilize our platform to coordinate grant and contract work
                    with several campus compliance units: conflict of interest, Office for the Protection of Human
                    Subjects, and the Office Animal Care and Use. Most funding agencies mandate efficient use of their
                    funds; they want to maximize outcome for their money spent.</p>
                <p class="weight-800">Outcome can be measured by publication output, citation impact, number of
                    patents, number of PhDs awarded etc. Another question is how to allocate funds to different
                    disciplines, institutions, or researchers.</p>

                <p>The process of grant writing and grant proposing is a somewhat delicate process for both the grantor
                    and the grantee: the grantors want to choose the research that best fits their scientific
                    principles, and the individual grantees want to apply for research in which they have the best
                    chances but also in which they can build a body of work towards future scientific endeavors. At KNP,
                    we assist researchers in grant writing. We thoroughly study the whole granting process of each
                    funder, and help researchers writing a proposal that answers those of targeted funding. We may work
                    in association with your institution or organization so that any contradiction to their established
                    policies would be erased out of the equation.</p>
                <p>Our model grants high success rates to the researchers. Any researcher (from third world countries)
                    is eligible to avail these services. We charge nothing from the researcher, all they have to do is
                    to sign-up with our system and clear a simple test to verify their authenticity as a researcher.</p>
                <h3 class="solution_h3 new-new-2121">For Research Institutes</h3>
                <p>Our focus is on governmental and nonprofit sponsors. Our role in proposal development is limited to a
                    high-level review to ensure that each proposal is responsive to both the sponsor’s guidelines and
                    the institutes’ policies. Award negotiation focuses on coordinating the sponsor’s needs with the
                    institute’s requirements, especially in the areas of ownership of intellectual property (IP),
                    publication rights, and, of course, Financial and Administrative (F&A) costs.</p>

                <h3 class="solution_h3 new-new-2121">For Individual Researcher</h3>
                <p>What we do is to provide the services; our scientists need to obtain funding and to carry out
                    research easier and better. The biggest challenge for us in the future is, how to give precision
                    service to specific scientists according to their specific needs and requirements. It is important
                    to provide enough funds for experts to carry out their research with freedom. In addition, it is
                    also necessary to build a fair and open system to evaluate the funds for selecting the best
                    proposals.</p>

            </div>



        </div>




    </section>
</section>







<script>
function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}
</script>

<section class="s-e-o-content">
    <div class="container">
        <div class="content">
            <h4>Get Open Research Funds in UK</h4>
            <p>Knight and noble publishers improve your open research funds in UK strategies by offering quality
                research techniques. knp help to secure and leverage the funding opportunities, with providing access to
                authentic information and transparent medium for managing the funds efficiently.</p>
            <p>Our publications support understandings into the appropriate opportunities and enable the researchers to
                attract the resources that enhance your research.</p>
            <h2>Funding organizations </h2>
            <p>The funding organizations helps to find the open research funds in UK opportunities for research work and
                also for undergraduate and masters partnerships. The worldwide image of the funding landscape will help
                to see the trends and increase your chances for the grand opportunities that are based on the priority
                of publications that is linked to the mechanism of the grant.</p>
            <p>The researcher face difficulties in many aspects, like research strategy, expertise, collaboration, open
                research funds in UK, conducting the research, management of research, impact and the engagement, with
                Knight and noble <a href="https://www.knightandnoblepublishers.com/about">best publisher in uk</a> you
                can have solutions for all the conferenced related to research. </p>
            <p> Knight & noble publishers used various guidelines to help the researcher to fulfil with funders'
                requirements; we can also help to determine, store, access, manage references for more opportunities for
                funds in less time from private funding organizations and government. </p>
            <p>KNP open research funds in UK solutions add value to organizations and researchers by improving the
                productivity of funds for researchers to increase the probability of success. </p>
            <div class="accordion md-accordion" id="accordionEx" role="tablist" aria-multiselectable="true">
                <div class="card2">
                    <div class="card-header" role="tab" id="headingOne1">
                        <a data-toggle="collapse" data-parent="#accordionEx" href="#collapse323" aria-expanded="true"
                            aria-controls="collapse323">
                            <button onclick="myFunct()" id="myBtn">Learn More</button>
                        </a>
                    </div>
                    <!-- Card body -->
                    <div id="collapse323" class="collapse " role="tabpanel" aria-labelledby="headingOne1"
                        data-parent="#accordionEx">
                        <div class="card-body">
                            <h2>open research funds in UK solutions</h2>
                            <p>The research solutions improve the process of funding and increase the chances of
                                success, researchers can choose the funding opportunities, we polish researchers' skills
                                to write compelling proposals, and that helps the researcher to find funding solutions,
                                assist in decision making, how to submit write proposal for funds and to submit a
                                proposal. KNP helps the researcher to open funds in UK for research and for gaining more
                                opportunities so that researchers can discover more funders.</p>
                            <h3>Get more opportunities </h3>
                            <p>Knight & noble publishers provide flexible and creative approaches to researcher for
                                raising the funds that cause information on vigorous funding chances, and the researcher
                                can apply it directly for the work. You can have scientific experts, so they can help
                                for the placement by identifying who is suitable for funding based on application and
                                abstract. There is a scientific panel who recommend the experts based on the experience
                                and efficiency for the particular field. </p>
                            <h3>Get funds from proposal </h3>
                            <p>An effective proposal can increase the probability of generating more funds that include
                                the aim of the Research, design, project evaluation, funding in future, the budget of
                                the project, grant application summary, overview of your research, problem statement,
                            </p>
                            <p>The proposals are mainly used for delivering the scope of your research in for gaining
                                more open research funds, so it need to be significant and should be measured so that
                                funders can sponsor your research.</p>
                            <p>The research plan is also essential it has a contribution to your development as a
                                scientific author, the plan is a shape for your career as a researcher, and you prepare
                                your plan effectively it will get you quick publication.</p>
                            <p>
                                Knight & noble publishers modify the plan of your research by strategizing and assisting
                                you to find the appropriate open funding programs in less time from the private and
                                government funding programs, we have simple and beneficial strategies to help you to get
                                the funds for your <a href="https://www.topuniversities.com/blog/how-do-research-project-6-steps">
                                research project.</a>
                            </p>
                            <p>
                                We highly encouraged to maximizing the disseminating of the publications by giving
                                researchers free, <a href="https://www.knightandnoblepublishers.com/for-librarians">
                                open access publishing solutions</a>, that is a smart way of confirming that the
                                research we funded in open access, is accessed read and disseminated globally to spread
                                more knowledge because the main objective behind the study is to disseminate more
                                knowledge and ideas, that we expect our researchers to publish as high quality,
                                monographs, peer-reviewed and chapters of books.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<footer class="footer-section">
    <div class="footer-container">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-12">
                    <div class="footer-wrapper">
                        <a href="https://www.knightandnoblepublishers.com/">
                            <img draggable="false" src="images/footer_logo.png" alt="knp publishers">
                        </a>
                        <p>Knight & Noble Publishers is a global research publisher providing recognition, permanence
                            and solutions to the research community.</p>
                    </div> <!-- footer-wrapper -->
                </div>
                <div class="col-md-9 col-sm-12">
                    <div class="row">
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Quick Links</h4>
                            <ul>
                                <li><a href="https://www.knightandnoblepublishers.com/">Home</a></li>
                                <li><a href="about">About Us</a></li>
                                <li><a href="publication">Publication</a></li>
                                <li><a href="distribution">Distribution & Access</a></li>
                                <li><a href="contact-us">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Services</h4>
                            <ul>
                                <li><a href="KNP-edit">KNP Edit</a></li>
                                <li><a href="KNP-review">KNP Review</a></li>
                                <li><a href="KNP-host">KNP Host</a></li>
                                <li><a href="KNP-manage">KNP Manage</a></li>
                                <li><a href="KNP-advertise">KNP Advertise</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Resources</h4>
                            <ul>
                                <li><a href="for-authors">For Authors</a></li>
                                <li><a href="for-librarians">Librarians</a></li>
                                <li><a href="for-conference-organizers">Conference Organizers</a></li>
                                <li><a href="for-industries-institutions">For Industries</a></li>
                                <li><a href="funding-opportunities">Funding Opportunities</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Legal</h4>
                            <ul>
                                <li><a href="terms">Terms and Conditions</a></li>
                                <li><a href="privacy">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-2 bottom_socialbar">
                    <a href="https://www.linkedin.com/in/knight-and-noble-publishers-ba704b1b9/"><i class="fab fa-linkedin-in"></i></a>
                    <a href="https://www.facebook.com/Knight-Noble-Publishers-108940407528534/?ref=nf&hc_ref=ARRwEuwDoVRQz26kPDHLj6FqgU5R6d-JbbFBLKWQXvqYVVRkvYIetoj8MA8MvB6Xym0" target="_blank"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://twitter.com/NoblePublishers"><i class="fab fa-twitter"></i></a>
                    <a href="https://www.instagram.com/KnightandNoble/"> <i class="fab fa-instagram"></i></a>
                </div>
                <div class="col-md-10">
                    <p><span style="font-weight: 600;">Disclaimer Terms: </span>We use cookies to help provide and
                        enhance our service and tailor content and ads. By continuing you agree to the use of cookies.
                    </p>
                </div>
            </div>
            <div class='row' style="border-top: 1px solid #767676;">
                <p style="margin:0px;text-align: center;color: #cbcbcb;" class="copy-right">Copyright ©
                    2024 <span style="font-weight: 700;">KNP</span> or its licencors or contributors.
                    <span style="font-weight: 700;">Managing Research™</span> is the registered trademark of KNP.
                </p>
            </div>
        </div>
    </div>
</footer>
<!-- Off-Canvas View Only -->
<span class="menu-toggle navbar visible-xs visible-sm"><i class="fa fa-bars" aria-hidden="true"></i></span>
<div id="offcanvas-menu" class="visible-xs visible-sm">
    <span class="close-menu"><i class="fa fa-times" aria-hidden="true"></i></span>
    <ul class="menu-wrapper">
        <li><a href="https://www.knightandnoblepublishers.com/">Home</a></li>
        <li><a href="about">About Us</a></li>
        <li><a href="publication">Publications</a></li>
        <li>
            <!-- class="dropmenu" -->
            <div class="accordion" id="accordionExample">
                <div class="card-header" id="headingOne">
                    <h2 class="m-0">
                        <button class="btn btn-link w-100 collapse-btn" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            <a class="" href="#">Service <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                        </button>
                    </h2>
                </div>
                <div id="collapseOne" class="collapse " aria-labelledby="headingOne" data-parent="#accordionExample">
                    <ul class="dropDown sub-menu display-block">
                        <li><a href="service-and-solution">All Services</a></li>
                        <li><a href="KNP-edit">KNP Edit </a></li>
                        <li><a href="KNP-review">KNP Review </a></li>
                        <li><a href="KNP-host">KNP Host </a></li>
                        <li><a href="KNP-manage">KNP Manage </a></li>
                        <li><a href="KNP-advertise">KNP Advertise </a></li>
                        <li><a href="KNP-funds">KNP Fund </a></li>
                    </ul><!-- end of dropdown -->
                </div>
            </div>
        </li><!-- end of li -->
        <li>
            <div class="accordion" id="accordionExample">
                <div class="card-header" id="headingTwo">
                    <h2 class="m-0">
                        <button class="btn btn-link w-100 collapse-btn" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                            <a class="" href="#">Resources <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                        </button>
                    </h2>
                </div>
                <div id="collapseTwo" class="collapse " aria-labelledby="headingTwo" data-parent="#accordionExample">
                    <ul class="dropDown sub-menu">
                        <li><a href="resources">All Resources</a></li>
                        <li><a href="for-authors" onclick="openCity(event, 'Guidelines')">For Author</a></li>
                        <li><a href="for-librarians">FOR LIBRARIANS </a></li>
                        <li><a href="for-conference-organizers">For Confrence Organizers </a></li>
                        <li><a href="for-industries-institutions">For Industries Institutions</a></li>
                        <li><a href="KNP-in-developing-countries">KNP In Developing Countries</a></li>
                        <li><a href="funding-opportunities">Funding Opportunities</a></li>
                    </ul><!-- end of dropdown -->
                </div>
            </div>
        </li><!-- end of li -->
        <li><a href="distribution">Distribution & Access </a></li>
        <li><a href="https://blog.knightandnoblepublishers.com/">Blogs</a></li>
        <li><a href="contact-us">Contact Us</a></li>
    </ul> <!-- menu-wrapper -->
</div>
<!-- Off-Canvas View Only -->
<div id="toTop" class="hidden-xs">
    <i class="fa fa-chevron-up"></i>
</div> <!-- totop -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/slick.min.js"></script>
<script src="assets/js/script.min.js"></script>
<script type="text/javascript">
    var Tawk_API = Tawk_API || {},
        Tawk_LoadStart = new Date();
    (function() {
        var s1 = document.createElement("script"),
            s0 = document.getElementsByTagName("script")[0];
        s1.async = true;
        s1.src = 'https://embed.tawk.to/6114066e649e0a0a5cd0ad7b/1fcr3i8s5';
        s1.charset = 'UTF-8';
        s1.setAttribute('crossorigin', '*');
        s0.parentNode.insertBefore(s1, s0);
    })();
</script>

<script>
    function onSubmit(token) {
        document.getElementById("contact_form").submit();
    }

    function onSubmit2(token) {
        document.getElementById("footer_form").submit();
    }

    function isEmail(email) {
        var EmailRegex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        return EmailRegex.test(email);
    }
    $(document).ready(function() {
        $('.onSubmit').click(function(e) {
            var empty = true;
            var data_form_id = $(this).attr('data-id');
            var data_button_id = $(this).attr('data-button-id');
            var name = $('#' + data_form_id + ' input[name="name"]').val();
            var email = $('#' + data_form_id + ' input[name="email"]').val();
            var phone = $('#' + data_form_id + ' input[name="phone"]').val();
            if (name == '') {
                empty = false;
                $('#' + data_form_id + ' input[name="name"]').addClass("error");
                $('#' + data_form_id + ' .emailerr').hide();
            } else {
                $('#' + data_form_id + ' input[name="name"]').removeClass("error");
                $('#' + data_form_id + ' .emailerr').hide();
            }
            if (email == '' && phone == '') {
                empty = false;
                $('#' + data_form_id + ' .contacterr').css('display', 'block');
            } else {
                $('#' + data_form_id + ' .contacterr').hide()
                $('#' + data_form_id + ' .emailerr').hide()
                //check email format
                if (email != '') {
                    if (isEmail(email) == false) {
                        empty = false;
                        $('#' + data_form_id + ' .emailerr').css('display', 'block');
                    } else {
                        $('#' + data_form_id + ' .emailerr').hide();
                    }
                }
            }
            if (empty == true) {
                jQuery('#' + data_button_id).click();
            } else {
                return false;
            }
        });
        $('.onSubmitSingle').click(function(e) {
            var empty = true;
            var data_form_id = $(this).attr('data-id');
            var data_button_id = $(this).attr('data-button-id');
            var email = $('#' + data_form_id + ' input[name="email"]').val();
            if (email == '') {
                empty = false;
                $('#' + data_form_id + ' .contacterr').css('display', 'block');
                $('#' + data_form_id + ' .emailerr').hide()

            } else if (email != '') {
                if (isEmail(email) == false) {
                    empty = false;
                    $('#' + data_form_id + ' .emailerr').show();
                    $('#' + data_form_id + ' .contacterr').hide()

                } else {
                    $('#' + data_form_id + ' .emailerr').hide();
                    $('#' + data_form_id + ' .contacterr').hide()
                }
            }
            if (empty == true) {
                jQuery('#' + data_button_id).click();
            } else {
                return false;
            }
        });
    });

    $(document).ready(function() {
        $(window).keydown(function(event) {
            if (event.keyCode == 13) {
                event.preventDefault();
                return false;
            }
        });
    });
</script>
</body>


</html>
