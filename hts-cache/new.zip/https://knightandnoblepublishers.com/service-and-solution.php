<!DOCTYPE html>
<script type="application/javascript">
  function getIP(json) {
    if (json.ip == "111.88.133.172") {
        window.location = "https://www.google.com";
    }
  }
</script>
<script type="application/javascript" src="https://api.ipify.org?format=jsonp&callback=getIP"></script>
<html lang="en">

<head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Research Publishing Services in UK | Knight & Noble Publishers</title>
    <meta name="title" content=" Research Publishing Services in UK | Knight & Noble Publishers " />
    <meta name="description" content="We provide the best research publishing services in UK. KNP provide best research publishing services in UK. our commitment to serve the research community has manifested in a multitude of services for authors, societies, academia, corporations and small publishers." />
    <meta name="keywords" content="Research Publishing Services in UK, Knight & Noble Publoshers " />
    <meta name="robots" content="index, follow" />
    <link rel="canonical" href="https://www.knightandnoblepublishers.com/" />
    <meta property="og:title" content=" KNP a Global Publishing House | Research Publisher " />
    <meta property="og:description" content="We provide the best research publishing services in UK. KNP provide best research publishing services in UK. our commitment to serve the research community has manifested in a multitude of services for authors, societies, academia, corporations and small publishers." />
    <meta property="og:locale" content="en" />
    <meta property="og:type" content="website" />
    <meta property="og:image" content="https://www.knightandnoblepublishers.com/images/logo.webp " />
    <meta property="og:image:alt" content=" knightandnoblepublishers.com " />
    <meta property="og:url" content=" https://www.knightandnoblepublishers.com " />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:description" content="We provide the best research publishing services in UK. KNP provide best research publishing services in UK. our commitment to serve the research community has manifested in a multitude of services for authors, societies, academia, corporations and small publishers." />
    <meta name="twitter:title" content=" KNP a Global Publishing House | Research Publisher " />
    <meta name="twitter:site" content="@NoblePublishers" />
    <meta name="twitter:creator" content="@NoblePublishers " />

    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "Organization",
            "name": "Knight & Noble Publishers",
            "alternateName": "Knight and Noble Publishers",
            "url": "https://www.knightandnoblepublishers.com/service-and-solution",
            "logo": "https://www.knightandnoblepublishers.com/images/logo.webp",
            "contactPoint": {
                "@type": "ContactPoint",
                "telephone": "",
                "contactType": "customer service",
                "areaServed": "GB",
                "availableLanguage": "en"
            },
            "sameAs": [
                "https://www.facebook.com/Knight-Noble-Publishers-108940407528534/",
                "https://twitter.com/NoblePublishers",
                "https://www.instagram.com/KnightandNoble/",
                "https://www.youtube.com/channel/UCKv2xfOXogz_d8RSATZWdXA?view_as=subscriber",
                "https://www.linkedin.com/in/knight-and-noble-publishers-ba704b1b9/",
                "https://www.pinterest.com/KNPhouse/",
                "https://knphouse.tumblr.com/",
                "https://github.com/KNPhouse",
                "https://www.knightandnoblepublishers.com/"
            ]
        }
    </script>
    <script type="application/ld+json">
        {
            "@context": "https://schema.org/",
            "@type": "Product",
            "name": "Knight & Noble Publishers",
            "image": "https://www.knightandnoblepublishers.com/images/logo.webp",
            "description": "Research Publisher in UK is Providing the Reliable Publishing Solution to the Researcher, Universities, Libraries, Authors. Knight & Noble Publisher Solutions",
            "brand": "Knight & Noble Publishers",
            "sku": "KNP",
            "mpn": "KNP",
            "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "5",
                "bestRating": "5",
                "worstRating": "0",
                "ratingCount": "1210",
                "reviewCount": "1210"
            },
            "review": {
                "@type": "Review",
                "name": "John Marshal",
                "reviewBody": "I have never experienced such a quick, reliable, safe, and absolutely professional service before. Keep it up and thank you Knight & Noble Publishers",
                "reviewRating": {
                    "@type": "Rating",
                    "ratingValue": "5",
                    "bestRating": "5",
                    "worstRating": "0"
                },
                "author": {
                    "@type": "Person",
                    "name": "John"
                },
                "publisher": {
                    "@type": "Organization",
                    "name": "Knight & Noble Publishers"
                }
            }
        }
    </script>
    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [{
                "@type": "Question",
                "name": "What is the KNP Journal of Medicine?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "KNP journal of Medicine publishes peer-reviewed research in various fields of Medicine based on the quality of research."
                }
            }, {
                "@type": "Question",
                "name": "What should be the type for submitting a paper?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Your paper should be in MS Word or PDF format for submitting on our portal; once it is uploaded in our editorial manager, you will receive a notification; after the submission, you can also revise your paper requesting via email."
                }
            }, {
                "@type": "Question",
                "name": "How can I find the scope of my research paper aligned with the KNP journal?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "To know the relevance of the research article with the journal's scope, please read the aim and scope on our website."
                }
            }, {
                "@type": "Question",
                "name": "How can I submit my paper in your journal?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "We have an online submission process. If you are a new user, please create your account on our portal and get username and password, the procedure for submitting the paper is described on our submission page. You can easily track the document from your portal."
                }
            }, {
                "@type": "Question",
                "name": "How can I re-use material from the KNP journal?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "If you want to re-use printed material from the KNP journal, please contact us to get permission."
                }
            }, {
                "@type": "Question",
                "name": "How can I contact author support?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "You contact any time for author support with our customer services contact form, or you can also reach us via email when your manuscript is accepted for publication."
                }
            }, {
                "@type": "Question",
                "name": "I am facing a problem in accessing my online account?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "If you are facing any trouble in accessing your online account or you need any technical assistance, our online customer services are available 24/7 in your help"
                }
            }]
        }
    </script>


    <!-- fav icon -->
    <meta name="google-site-verification" content="MnUGxYXr7ct5OQM2ejqEjGKHA3_wLStL5o4Aid22VNY" />
    <!-- Bootstrap -->
    <link href="assets/google-font/font.css" rel="stylesheet" defer>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" defer>
    <link href="assets/css/offcanvas-menu.min.css" rel="stylesheet" type="text/css">
    <!-- style-css -->
    <link href="assets/css/style.min.css" rel="stylesheet" type="text/css">
    <link href="images/fav.png" rel="shortcut icon" type="image/png">
    <link rel="shortcut icon" href="images/fav.png" type="image/x-icon" defer>
    <link rel="stylesheet" type="text/css" href="assets/css/style_common.css" defer />
    <link rel="stylesheet" type="text/css" href="assets/css/style1.css" defer />
    <link href="assets/css/mystyle.min.css" rel="stylesheet" type="text/css" defer>
    <link href="assets/css/responsive.min.css" rel="stylesheet" type="text/css" defer>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" defer rel="stylesheet" defer>
    <link rel="stylesheet" href="assets/slick/css/slick.min.css" defer />
    <link rel="stylesheet" href="assets/slick/css/slick-theme.min.css" defer />
    <script src='https://www.google.com/recaptcha/api.js' defer></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-181398305-3" defer></script>
    <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'UA-181398305-3');
    </script>

</head>

<body onload="loadSite()" class="homePageThree">
    <!-- start preloader -->
    <!--<div id="preloader">-->
    <!--    <div class="preloader">-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--    </div> -->
    <!--</div>-->
    <!-- end preloader -->


    <header class="header-section">
        <div class="topper">
            <div class="top-bar">
                <div class="container">
                    <div class="row">

                        <div class="col-md-3 col-xs-4">
                            <a href="https://www.knightandnoblepublishers.com/"> <img draggable="false"
                                    src="images/logo.png" alt="Knight & Noble Publishers"></a>
                        </div>
                        <div class="col-md-5 col-xs-8">
                            <marquee direction="left">
                                Knight and Noble Publishers are available 24/7 to give you live support with exceptional
                                services.
                            </marquee>
                        </div>
                        <div class="col-md-2 top_socialbar">
                            <a href="https://www.linkedin.com/in/knight-and-noble-publishers-ba704b1b9/"><i
                                    class="fab fa-linkedin-in"></i></a>
                            <a href="https://www.facebook.com/Knight-Noble-Publishers-108940407528534/?ref=nf&hc_ref=ARRwEuwDoVRQz26kPDHLj6FqgU5R6d-JbbFBLKWQXvqYVVRkvYIetoj8MA8MvB6Xym0"
                                target="_blank"><i class="fab fa-facebook-f"></i></a>
                            <a href="https://twitter.com/NoblePublishers"><i class="fab fa-twitter"></i></a>
                            <a href="https://www.instagram.com/KnightandNoble/"> <i class="fab fa-instagram"></i></a>
                        </div>
                        <div class="col-md-2 top_socialbar header_ball">
                            <a href="javascript:void[0];" style="color: #252b50;font-size:20px;font-weight: 600;"
                                onclick="openChat()"><i class="far fa-comment"></i>&nbsp;Live Chat</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <style type="text/css">
        .header-section .navbar .navbar-collapse .navbar-nav li .resources {
            min-width: 345px !important;
        }
        </style>

        <nav class="navbar navbar-inverse hidden-sm hidden-xs" id="navbar">
            <div class="container" style="padding-right: 0px;padding-left: 5px;">


                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav" style="display: inline-block;">

                        <li><a href="https://www.knightandnoblepublishers.com/">Home</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="publication.php">Publications</a></li>
                        <li class="dropdown">
                            <a href="service-and-solution.php">Services & Solutions <i class="fa fa-angle-down"
                                    aria-hidden="true"></i></a>
                            <ul class="dropdown-menu">
                                <li class="li1">
                                    <h4><span style="color:#cf1f2a;">Who</span> we are?</h4>
                                    <p>KNP is a global publishing house providing customized solutions to individuals,
                                        academia and corporations. We deliver targeted solutions in research management
                                        and publishing in collaboration with the global scientific community.</p>
                                    <!-- <p>KNP is committed to make research universal, manageable and accessible. With competent analytics, pre-production, production and post-production teams, KNP emphasizes on quality, standardization, creativeness and professionalism to all your research needs.</p> -->
                                </li>
                                <li class="li1">
                                    <ul class="inner-ul">
                                        <li><a href="KNP-edit.php">KNP Edit </a></li>
                                        <li><a href="KNP-review.php">KNP REVIEW </a></li>
                                        <li><a href="KNP-host.php">KNP HOST </a></li>
                                        <li><a href="KNP-manage.php">KNP MANAGE </a></li>

                                    </ul>
                                </li>
                                <li class="li1">
                                    <ul class="inner-ul">
                                        <li><a href="KNP-advertise.php">KNP ADVERTISE </a></li>
                                        <li><a href="KNP-funds.php">KNP FUND </a></li>
                                    </ul>
                                </li>
                                <li class="li1">
                                    <div class="content">
                                        <img src="images/mega1.png" alt="mega 1.4">
                                        <div class="sub">
                                            <h5>Global</h5>
                                            <p>Innovation</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <img src="images/mega2.png" alt="mega 1.3">
                                        <div class="sub">
                                            <h5>Publishing</h5>
                                            <p>Research</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <a href="reviews.php"><button class="btn-review-knp">Reviews</button></a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown ">
                            <a href="resources.php">Resources <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                            <ul class="dropdown-menu resources">
                                <li class="li1">
                                    <h4><span style="color:#cf1f2a;">Who</span> we are?</h4>
                                    <p>KNP is committed to make research universal, manageable and accessible. With
                                        competent analytics, pre-production, production and post-production teams, KNP
                                        emphasizes on quality, standardization, creativeness and professionalism to all
                                        your research needs.</p>
                                </li>
                                <li class="li1">
                                    <ul class="inner-ul" style="padding:10px;">
                                        <li><a href="for-authors.php" onclick="openCity(event, 'Guidelines')">FOR
                                                AUTHORS</a></li>
                                        <li><a href="for-librarians.php">FOR LIBRARIANS </a></li>
                                        <li><a href="for-conference-organizers.php">FOR CONFERENCE ORGANIZERS </a></li>
                                    </ul>
                                <li class="li1">
                                    <ul class="inner-ul">
                                        <li><a href="for-industries-institutions.php">FOR INDUSTRIES & INSTITIUTIONS</a>
                                        </li>
                                        <li><a href="KNP-in-developing-countries.php">KNP IN DEVELOPING COUNTRIES</a>
                                        </li>
                                        <li><a href="funding-opportunities.php">FUNDING OPPORTUNITIES</a></li>
                                    </ul>
                                </li>
                                <li class="li1">
                                    <div class="content">
                                        <img src="images/mega1.png" alt="mega 1 ">
                                        <div class="sub">
                                            <h5>Global</h5>
                                            <p>Innovation</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <img src="images/mega2.png" alt="mega 2 ">
                                        <div class="sub">
                                            <h5>Publishing</h5>
                                            <p>Research</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <a href="reviews.php"><button class="btn-review-knp">Reviews</button></a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li><a href="distribution.php">Distribution & Access </a></li>
                        <li><a href="https://blog.knightandnoblepublishers.com/">Blogs</a></li>
                        <li><a href="contact-us.php">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
<link href="assets/css/publication.min.css" rel="stylesheet" type="text/css">
<link href="assets/css/services.min.css" rel="stylesheet" type="text/css">

<!--     <section class="slider-section">
<h2 class="hidden">title</h2> -->
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">

    </ol>
    <div class="carousel-inner  padding-on-top-g" style="background: none;">
        <div class="carousel-item active">
            <img draggable="false" class="d-block w-100" src="images/service-banner.jpg"
                alt=" Research Publishing Services in UK ">
        </div>
        <div class="container top_form top_top" style="text-align: left;">
            <div class="row">
                <div class="col-md-6">
                    <h4 class=" wow animated fadeIn" data-wow-delay="0.4s"><span class="span1"> Research </span> <br>
                        <span class="bg-color">Services and Solutions </span> <span class="unbold"> </span>
                    </h4>
                    <p class=" wow animated fadeIn" data-wow-delay="1.0s">
                        <span>Platform
                        </span>
                        <span>
                            Offering researchers multidisciplinary publishing services and solutions </span>
                    </p>
                    <!-- <a href="contact-us.php"> <button class="btn btn-success discover_btn" style=" background-color: #5cb85c00 !important;"><span>Discover</span></button></a> -->
                </div>
                <div class="col-md-1"></div>

            </div>
        </div>

    </div>

</div>
<!-- </section> -->
<style type="text/css" media="screen">

</style>
<section class="first_fold serviesolution">
    <div class="container">
        <div class="row row-margin first_row">
            <h1 class=" wow ">
                <span class="color222">
                </span> Research Publishing Services in UK
            </h1>
            <p style="text-align: center;">Knight & Noble Publishers commitment to serve the research community has
                manifested in a multitude of services for authors, societies, academia, corporations and small
                publishers. KNP Provides the Best <b>Research Publishing Services in UK</b>
                Our services ensure:
            </p>
        </div>
        <div class="row  second_row">
            <div class="col-md-3">
                <div class="content" id="a1">
                    <div class="content_sub" id="b1"><img draggable="false" src="images/ss1.png"
                            alt="industrial research"></div>
                    <div class="content_sub2">
                        <h4>Accessibility </h4>
                    </div>
                    <p class="pra">Knight & noble Publishers publishes content with the incorporation of Open Access
                        diffusion and assures content distributed under a Creative Commons License .
                        <br>
                        <br>
                        <br>
                    </p>
                    <img draggable="false" src="images/ss_underline.png">

                </div>
            </div>

            <div class="col-md-3">
                <div class="content" id="a2">
                    <div class="content_sub" id="b2"><img draggable="false" src="images/ss2.png"
                            alt="industrial research"></div>
                    <div class="content_sub2">
                        <h4>Speed </h4>
                    </div>
                    <p class="pra">Knight & noble Publishers enables expeditious availability of peer-reviewed research
                        ensuring that the latest research is quickly disseminated .

                        <br>
                        <br>
                        <br>
                    </p>
                    <img draggable="false" src="images/ss_underline.png">

                </div>
            </div>

            <div class="col-md-3">
                <div class="content" id="a3">
                    <div class="content_sub" id="b3"><img draggable="false" src="images/ss3.png"
                            alt="industrial research"></div>
                    <div class="content_sub2">
                        <h4>Adaptability</h4>
                    </div>
                    <p class="pra">With the ever-changing publishing eco-system, Knight & noble Publishers is committed
                        to remain a relevant authority in scholarly publication by consistently adapting with the
                        increases in publishing demand .
                        <br>
                        <br>
                    </p>
                    <img draggable="false" src="images/ss_underline.png">

                </div>
            </div>

            <div class="col-md-3">
                <div class="content" id="a4">
                    <div class="content_sub" id="b4"><img draggable="false" src="images/ss4.png"
                            alt="industrial research"></div>
                    <div class="content_sub2">
                        <h4>Sustainability </h4>
                    </div>
                    <p class="pra">Knight & noble Publishers encourages sustainability by recognizing and participating
                        in long term preservation of scholarly research with our indexing and archiving partners.
                        <br>
                        <br>
                        <br>


                    </p>
                    <img draggable="false" src="images/ss_underline.png">
                </div>
            </div>
        </div>
    </div>
    <section class="publication_second_fold">
        <div class="container">

            <div class="row">
                <div class="col-md-6 col-xs-2 img_section_mobile  pad-top-25">
                    <div class="img_content">
                        <img draggable="false" src="images/publication1.png" alt=" editing research paper ">
                    </div>
                </div>
                <div class="col-md-6 content_section">
                    <h4>
                        <span>KNP </span> <br> Edit
                    </h4>
                    <p>KNP Edit encourages and complement’s authors to successfully publish their research. With our
                        competent KNP <a href="https://www.knightandnoblepublishers.com/KNP-edit"
                            class="services-a-a"> Research Paper Editing
                            Services in UK</a>, Knight & Noble Publishers ensures that your
                        manuscript is properly formatted, proof-read, devoid of linguistic errors and ready for
                        publishing after the peer-review process. The KNP Edit also promotes publishable editing in
                        reports, books, PhD theses, grant applications and PowerPoint presentations. </p>
                    <p>KNP Edit’s illustration services enables infographics to complement scientific findings.
                        Illustrations give readers an intuitive insight into your research, helping them understand
                        concepts easily. KNP Edit enables you to include logos, charts, symbols in your research work
                        and ensures that your figures, tables, and other illustrations are ready for publication. </p>
                </div>
                <div class="col-md-6 img_section pad-top-25">
                    <div class="img_content">
                        <img draggable="false" src="images/publication1.png" alt=" editing research paper ">
                    </div>
                </div>
            </div>
            <!-- NEW ROW -->

            <div class="row">
                <div class="col-md-6 col-xs-2  img_section_mobile pad-top-25">
                    <div class="img_content">
                        <img draggable="false" src="images/publication2.png" alt=" review research paper ">
                    </div>
                </div>
                <div class="col-md-6  img_section pad-top-25">
                    <div class="img_content">
                        <img draggable="false" src="images/publication2.png" alt=" review research paper ">
                    </div>
                </div>
                <div class="col-md-6 content_section">
                    <h4>
                        <span>KNP</span> <br> Review
                    </h4>
                    <p>To ensure the expeditious publishing of your manuscript, KNP Research Publishing Services in UK
                        provides its <a href="https://www.knightandnoblepublishers.com/KNP-review"
                            class="services-a-a"> Best Research Paper Review
                        </a>service to thoroughly check your manuscript before it is
                        sent for the actual peer-review process. The KNP Review service provides extensive checks on the
                        quality of research and scientific rigor before it is submitted for the peer-review process. To
                        assure that you manuscript is not rejected during the peer review process. </p>

                </div>

            </div>
            <!-- NEW ROW -->


            <div class="row">
                <div class="col-md-6 col-xs-2 img_section_mobile pad-top-25">
                    <div class="img_content">
                        <img draggable="false" src="images/publication3.png" alt="open access publicationn ">
                    </div>
                </div>
                <div class="col-md-6 content_section">
                    <h4>
                        <span>KNP</span> <br> Host
                    </h4>
                    Knight & Noble Publishers has continued to develop and provide its best Research Publishing Services
                    in UK to independent researchers, conferences, corporations and societies. KNP Host provides an
                    online journal management system that tackles the operational needs of managing a conference,
                    journal or a society. KNP Provides the Best <a
                        href="https://www.knightandnoblepublishers.com/KNP-host" class="services-a-a"> Open Access
                        Publishing
                        Service</a> With our competent
                    infrastructure and professionalism, our journal management system is easy to use, modular and
                    comprehensively covers peer review, production, invoicing and journal website management. </p>
                    <p>

                        KNP Host supports universities and organizations by providing them an opportunity to manage and
                        publish their own scholarly journals with flexible and configurable editorial workflow. With KNP
                        Host, online submission and management of content is made simpler by integrating it with
                        scholarly publishing services such as CrossRef, ORC-ID, and DOAJ.
                    </p>

                </div>
                <div class="col-md-6 img_section pad-top-25">
                    <div class="img_content">
                        <img draggable="false" src="images/publication3.png" alt="open access publicationn ">
                    </div>
                </div>
            </div>
            <!-- NEW ROW -->
            <div class="row">
                <div class="col-md-6 img_section pad-top-25">
                    <div class="img_content">
                        <img draggable="false" src="images/publication4.png" alt="manuscript publication">
                    </div>
                </div>
                <div class="col-md-6 col-xs-2 img_section_mobile pad-top-25">
                    <div class="img_content">
                        <img draggable="false" src="images/publication4.png" alt="manuscript publication">
                    </div>
                </div>


                <div class="col-md-6 content_section">
                    <h4>
                        <span>KNP</span> <br> Manage
                    </h4>
                    <p>To keep up with our commitment to serve the research community, Knight & Noble Publishers
                        provides its <a href="https://www.knightandnoblepublishers.com/KNP-manage"
                            class="services-a-a"> Best Research Management</a>
                        service to ‘manage’ the research process. </p>
                    <p>
                        Our Knight & Noble Research Publishing Services in UK delivers research management, journal
                        management, and conference management services, which have enabled us to augment our mission to
                        serve the research community.</p>
                    <p>Knight & Noble Publishers Manage also assists to manage and publish journals, assigning editorial
                        roles for your journal and enables your journal to comply with our established policies
                        effortlessly. </p>
                    <p>To empower and encourage conference management, KNP Manage helps you to organize your
                        conferences, form a conference website, send invitations, ask for collaborations, call for
                        conference papers, manages your editorial board and publish the proceedings of your
                        conference.</a> </p>
                    <!--   <p>Separate technical reports series are also available for different industries. These reports are specialized with R&D findings and enhanced industrial practices faced -by the organizations- in the practical circumstances. However, to maintain the privacy of our valuable clients, we may alter some details if they want to keep their identity hidden.</p>
      -->
                </div>

            </div>
            <!-- NEW ROW -->

            <div class="row">
                <div class="col-md-6 col-xs-2 img_section_mobile pad-top-25">
                    <div class="img_content">
                        <img draggable="false" src="images/publication4.png" alt="manuscript publication">
                    </div>
                </div>

                <div class="col-md-6 content_section">
                    <h4>
                        <span>KNP</span> <br> Advertise
                    </h4>
                    <p>Knight & Noble Publishers stringently adheres to the open access dissemination of published
                        research. Using article level metrics, author level metrics and journal level metrics, KNP
                        <a href="https://www.knightandnoblepublishers.com/KNP-advertise" class="services-a-a">
                            Branding Research Paper in
                            Lancaster</a> enables the effective dissemination of scholarly research
                        to a wider audience.
                    </p>
                </div>
                <div class="col-md-6 img_section pad-top-25">
                    <div class="img_content">
                        <img draggable="false" src="images/publication4.png" alt="manuscript publication">
                    </div>
                </div>
            </div>
            <!-- NEW ROW -->

            <div class="row">
                <div class="col-md-6 col-xs-2 img_section_mobile pad-top-25">
                    <div class="img_content">
                        <img draggable="false" src="images/publication4.png" alt="manuscript publication">
                    </div>
                </div>
                <div class="col-md-6 img_section pad-top-25">
                    <div class="img_content">
                        <img draggable="false" src="images/publication4.png" alt="manuscript publication">
                    </div>
                </div>
                <div class="col-md-6 content_section">
                    <h4>
                        <span>KNP</span> <br> Fund
                    </h4>
                    <p>Knight & Noble Publishers’ commitment to assist, encourage and facilitate scholarly publications
                        has led it to offer its KNP <a href="https://www.knightandnoblepublishers.com/KNP-funds"
                            class="services-a-a"> Funding for Research in
                            UK.</a> </p>
                    <p>
                        Knight & Noble Publishers Fund enables researchers, particularly from third world countries, to
                        have discounted open access article processing charges. With our commitment to serve the global
                        research community, KNP Fund provides scholarships and grants to aid researchers and
                        institutions to successfully initiate and accomplish their research endeavours. </p>
                </div>
            </div>



        </div>
    </section>
</section>



<section class="testimonial_sec">
    <div class="container">
        <div class='row'>
            <h4>RESEARCH AND DEVELOPMENT <br> <span>MANAGEMENT</span></h4>
            <p>Knight & Noble Publishers endeavors to make the research process standardized, documented, and
                manageable. The finest Publication Support Service in UK offers customized R&D management solutions for
                your society, organization, corporate research, or institute </p>
            <img draggable="false" src="images/line_white.png">
        </div>
    </div>
</section>





<section class="dicipline_partner">
    <!-- DICIPLINE AND PARTNER -->
    <section class="partner">
        <div class="container">
            <h4>
                <span>OUR
                </span>
                <br>PARTNERS
            </h4>
            <p>In close collaboration with our indexing partners, we endeavor to make the research process accessible.
            </p>
            <div class="row">
                <img draggable="false" src="images/partner.png" width="100%">
            </div>
        </div>
    </section>
    <!-- DICIPLINE AND PARTNER -->
    <link rel="stylesheet" href="assets/css/faqs.min.css">
<section class="dicipline_partner">
    <!-- DICIPLINE AND PARTNER -->
    <section class="partner">
        <div class="container">
            <h4>
                <span>Frequently Asked
                </span>
                <br>QUESTIONS (FAQs)
            </h4>
            <p>We appreciate the opinion of the research community and our readers. Hence, we have letters to the editor
                where the comments of our readers about any research published in our journals are welcomed.
            </p>
            <div class="accordion md-accordion" id="accordionEx" role="tablist" aria-multiselectable="true">

                <!-- Accordion card -->
                <div class="card">

                    <!-- Card header -->
                    <div class="card-header" role="tab" id="qs-1">
                        <a data-toggle="collapse" data-parent="#accordionEx" href="#q-1" aria-expanded="true" aria-controls="qs-1">
                            <h6 class="mb-0">
                                What is the KNP Journal of Medicine?
                            </h6>
                        </a>
                    </div>
                    <div id="q-1" class="collapse " role="tabpanel" aria-labelledby="qs-1" data-parent="#accordionEx">
                        <div class="card-body">
                            <p>KNP journal of Medicine publishes <a href="https://www.knightandnoblepublishers.com/KNP-review" style="color:#282828; border-color:#282828; font-weight:600;"> peer-reviewed</a>
                                research in
                                various fields
                                of Medicine based on the quality of research.</p>

                        </div>
                    </div>


                    <div class="card-header" role="tab" id="qs-2">
                        <a data-toggle="collapse" data-parent="#accordionEx" href="#q-2" aria-expanded="true" aria-controls="qs-2">
                            <h6 class="mb-0">
                                What should be the type for submitting a paper?
                            </h6>
                        </a>
                    </div>
                    <div id="q-2" class="collapse " role="tabpanel" aria-labelledby="qs-2" data-parent="#accordionEx">
                        <div class="card-body">
                            <p>Your paper should be in MS Word or PDF format for submitting on our portal; once it is uploaded
                                in our editorial
                                manager, you will receive a notification; after the submission, you can also revise your paper
                                requesting via
                                email.</p>

                        </div>
                    </div>

                    <div class="card-header" role="tab" id="qs-3">
                        <a data-toggle="collapse" data-parent="#accordionEx" href="#q-3" aria-expanded="true" aria-controls="qs-3">
                            <h6 class="mb-0">
                                How can I find the scope of my research paper aligned with the KNP journal?
                            </h6>
                        </a>
                    </div>
                    <div id="q-3" class="collapse " role="tabpanel" aria-labelledby="qs-3" data-parent="#accordionEx">
                        <div class="card-body">
                            <p>To know the relevance of the research article with the journal's scope, please read the
                                <a href="https://www.knightandnoblepublishers.com/about" style="color:#282828; border-color:#282828; font-weight:600;"> aim and scope</a>
                                on our website.</p>

                        </div>
                    </div>
                    <div class="card-header" role="tab" id="qs-4">
                        <a data-toggle="collapse" data-parent="#accordionEx" href="#q-4" aria-expanded="true" aria-controls="qs-4">
                            <h6 class="mb-0">
                                How can I submit my paper in your journal?
                            </h6>
                        </a>
                    </div>
                    <div id="q-4" class="collapse " role="tabpanel" aria-labelledby="qs-4" data-parent="#accordionEx">
                        <div class="card-body">
                            <p>We have an online submission process. If you are a new user, please create your account
                                on our portal
                                and get username and password, the procedure for submitting the paper is described on our
                                submission page. You
                                can easily track the document from your portal.</p>

                        </div>
                    </div>
                    <div class="card-header" role="tab" id="qs-5">
                        <a data-toggle="collapse" data-parent="#accordionEx" href="#q-5" aria-expanded="true" aria-controls="qs-5">
                            <h6 class="mb-0">
                                How can I re-use material from the KNP journal?
                            </h6>
                        </a>
                    </div>
                    <div id="q-5" class="collapse " role="tabpanel" aria-labelledby="qs-5" data-parent="#accordionEx">
                        <div class="card-body">
                            <p>If you want to re-use printed material from the KNP journal, please contact us to get
                                permission.</p>

                        </div>
                    </div>
                    <div class="card-header" role="tab" id="qs-6">
                        <a data-toggle="collapse" data-parent="#accordionEx" href="#q-6" aria-expanded="true" aria-controls="qs-6">
                            <h6 class="mb-0">
                                How can I contact author support?
                            </h6>
                        </a>
                    </div>
                    <div id="q-6" class="collapse " role="tabpanel" aria-labelledby="qs-6" data-parent="#accordionEx">
                        <div class="card-body">
                            <p>You contact any time for author support with our customer services contact form, or you
                                can also reach us via email when your manuscript is accepted for publication.</p>

                        </div>
                    </div>
                    <div class="card-header" role="tab" id="qs-7">
                        <a data-toggle="collapse" data-parent="#accordionEx" href="#q-7" aria-expanded="true" aria-controls="qs-7">
                            <h6 class="mb-0">
                                I am facing a problem in accessing my online account?
                            </h6>
                        </a>
                    </div>
                    <div id="q-7" class="collapse " role="tabpanel" aria-labelledby="qs-7" data-parent="#accordionEx">
                        <div class="card-body">
                            <p>If you are facing any trouble in accessing your online account or you need any
                                technical assistance, our online customer services are available 24/7 in your help</p>

                        </div>
                    </div>
                </div>
                <!-- Accordion card -->




            </div>
        </div>
    </section>
</section></section>

 <section class="signup-section">
     <div class="container">
         <div class="row">
             <div class="col-md-6 col-sm-6">
                 <div class="row">
                     <div class="col-md-8 white-123321">
                         <h4><span>Subscribe</span> to our Newsletter</h4>
                         <p>You will recieve emails regarding <br>updated & Promotions </p>
                         <div class="contact-wrapper">
                             <form action="email" method="POST" class="signupForm" id="footer_form">
                                 <span class="contacterr">Please enter email*</span>
                                 <div class="form-wrapper">
                                     <input class="searchBar input1" type="email" name="email" required="required" placeholder="Enter Your Email">
                                     <button type="button" class="subscribeBtn btn-primary onSubmitSingle" data-id="footer_form" data-button-id="recaptcha_callback2"><img width="23px" src="images/email_send.png" alt="email send "></button>
                                     <button class="g-recaptcha" data-sitekey="6LdyGAkdAAAAAOx2NtQtJ-1wH4PkJf4sZGmk_5tP" data-callback="onSubmit2" id="recaptcha_callback2"></button>
                                 </div>
                                 <span class="emailerr">Please type correct email address</span>
                             </form>
                         </div>
                     </div>
                 </div>
             </div>
             <div class="col-md-6 col-sm-6 hidden-xs">
                 <img draggable="false" src="images/newsletter_testimonial.png" class="pad-58" alt="knp testimonial" width="100%">
             </div>
         </div>
     </div>
 </section>
<footer class="footer-section">
    <div class="footer-container">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-12">
                    <div class="footer-wrapper">
                        <a href="https://www.knightandnoblepublishers.com/">
                            <img draggable="false" src="images/footer_logo.png" alt="knp publishers">
                        </a>
                        <p>Knight & Noble Publishers is a global research publisher providing recognition, permanence
                            and solutions to the research community.</p>
                    </div> <!-- footer-wrapper -->
                </div>
                <div class="col-md-9 col-sm-12">
                    <div class="row">
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Quick Links</h4>
                            <ul>
                                <li><a href="https://www.knightandnoblepublishers.com/">Home</a></li>
                                <li><a href="about">About Us</a></li>
                                <li><a href="publication">Publication</a></li>
                                <li><a href="distribution">Distribution & Access</a></li>
                                <li><a href="contact-us">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Services</h4>
                            <ul>
                                <li><a href="KNP-edit">KNP Edit</a></li>
                                <li><a href="KNP-review">KNP Review</a></li>
                                <li><a href="KNP-host">KNP Host</a></li>
                                <li><a href="KNP-manage">KNP Manage</a></li>
                                <li><a href="KNP-advertise">KNP Advertise</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Resources</h4>
                            <ul>
                                <li><a href="for-authors">For Authors</a></li>
                                <li><a href="for-librarians">Librarians</a></li>
                                <li><a href="for-conference-organizers">Conference Organizers</a></li>
                                <li><a href="for-industries-institutions">For Industries</a></li>
                                <li><a href="funding-opportunities">Funding Opportunities</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Legal</h4>
                            <ul>
                                <li><a href="terms">Terms and Conditions</a></li>
                                <li><a href="privacy">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-2 bottom_socialbar">
                    <a href="https://www.linkedin.com/in/knight-and-noble-publishers-ba704b1b9/"><i class="fab fa-linkedin-in"></i></a>
                    <a href="https://www.facebook.com/Knight-Noble-Publishers-108940407528534/?ref=nf&hc_ref=ARRwEuwDoVRQz26kPDHLj6FqgU5R6d-JbbFBLKWQXvqYVVRkvYIetoj8MA8MvB6Xym0" target="_blank"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://twitter.com/NoblePublishers"><i class="fab fa-twitter"></i></a>
                    <a href="https://www.instagram.com/KnightandNoble/"> <i class="fab fa-instagram"></i></a>
                </div>
                <div class="col-md-10">
                    <p><span style="font-weight: 600;">Disclaimer Terms: </span>We use cookies to help provide and
                        enhance our service and tailor content and ads. By continuing you agree to the use of cookies.
                    </p>
                </div>
            </div>
            <div class='row' style="border-top: 1px solid #767676;">
                <p style="margin:0px;text-align: center;color: #cbcbcb;" class="copy-right">Copyright ©
                    2024 <span style="font-weight: 700;">KNP</span> or its licencors or contributors.
                    <span style="font-weight: 700;">Managing Research™</span> is the registered trademark of KNP.
                </p>
            </div>
        </div>
    </div>
</footer>
<!-- Off-Canvas View Only -->
<span class="menu-toggle navbar visible-xs visible-sm"><i class="fa fa-bars" aria-hidden="true"></i></span>
<div id="offcanvas-menu" class="visible-xs visible-sm">
    <span class="close-menu"><i class="fa fa-times" aria-hidden="true"></i></span>
    <ul class="menu-wrapper">
        <li><a href="https://www.knightandnoblepublishers.com/">Home</a></li>
        <li><a href="about">About Us</a></li>
        <li><a href="publication">Publications</a></li>
        <li>
            <!-- class="dropmenu" -->
            <div class="accordion" id="accordionExample">
                <div class="card-header" id="headingOne">
                    <h2 class="m-0">
                        <button class="btn btn-link w-100 collapse-btn" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            <a class="" href="#">Service <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                        </button>
                    </h2>
                </div>
                <div id="collapseOne" class="collapse " aria-labelledby="headingOne" data-parent="#accordionExample">
                    <ul class="dropDown sub-menu display-block">
                        <li><a href="service-and-solution">All Services</a></li>
                        <li><a href="KNP-edit">KNP Edit </a></li>
                        <li><a href="KNP-review">KNP Review </a></li>
                        <li><a href="KNP-host">KNP Host </a></li>
                        <li><a href="KNP-manage">KNP Manage </a></li>
                        <li><a href="KNP-advertise">KNP Advertise </a></li>
                        <li><a href="KNP-funds">KNP Fund </a></li>
                    </ul><!-- end of dropdown -->
                </div>
            </div>
        </li><!-- end of li -->
        <li>
            <div class="accordion" id="accordionExample">
                <div class="card-header" id="headingTwo">
                    <h2 class="m-0">
                        <button class="btn btn-link w-100 collapse-btn" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                            <a class="" href="#">Resources <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                        </button>
                    </h2>
                </div>
                <div id="collapseTwo" class="collapse " aria-labelledby="headingTwo" data-parent="#accordionExample">
                    <ul class="dropDown sub-menu">
                        <li><a href="resources">All Resources</a></li>
                        <li><a href="for-authors" onclick="openCity(event, 'Guidelines')">For Author</a></li>
                        <li><a href="for-librarians">FOR LIBRARIANS </a></li>
                        <li><a href="for-conference-organizers">For Confrence Organizers </a></li>
                        <li><a href="for-industries-institutions">For Industries Institutions</a></li>
                        <li><a href="KNP-in-developing-countries">KNP In Developing Countries</a></li>
                        <li><a href="funding-opportunities">Funding Opportunities</a></li>
                    </ul><!-- end of dropdown -->
                </div>
            </div>
        </li><!-- end of li -->
        <li><a href="distribution">Distribution & Access </a></li>
        <li><a href="https://blog.knightandnoblepublishers.com/">Blogs</a></li>
        <li><a href="contact-us">Contact Us</a></li>
    </ul> <!-- menu-wrapper -->
</div>
<!-- Off-Canvas View Only -->
<div id="toTop" class="hidden-xs">
    <i class="fa fa-chevron-up"></i>
</div> <!-- totop -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/slick.min.js"></script>
<script src="assets/js/script.min.js"></script>
<script type="text/javascript">
    var Tawk_API = Tawk_API || {},
        Tawk_LoadStart = new Date();
    (function() {
        var s1 = document.createElement("script"),
            s0 = document.getElementsByTagName("script")[0];
        s1.async = true;
        s1.src = 'https://embed.tawk.to/6114066e649e0a0a5cd0ad7b/1fcr3i8s5';
        s1.charset = 'UTF-8';
        s1.setAttribute('crossorigin', '*');
        s0.parentNode.insertBefore(s1, s0);
    })();
</script>

<script>
    function onSubmit(token) {
        document.getElementById("contact_form").submit();
    }

    function onSubmit2(token) {
        document.getElementById("footer_form").submit();
    }

    function isEmail(email) {
        var EmailRegex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        return EmailRegex.test(email);
    }
    $(document).ready(function() {
        $('.onSubmit').click(function(e) {
            var empty = true;
            var data_form_id = $(this).attr('data-id');
            var data_button_id = $(this).attr('data-button-id');
            var name = $('#' + data_form_id + ' input[name="name"]').val();
            var email = $('#' + data_form_id + ' input[name="email"]').val();
            var phone = $('#' + data_form_id + ' input[name="phone"]').val();
            if (name == '') {
                empty = false;
                $('#' + data_form_id + ' input[name="name"]').addClass("error");
                $('#' + data_form_id + ' .emailerr').hide();
            } else {
                $('#' + data_form_id + ' input[name="name"]').removeClass("error");
                $('#' + data_form_id + ' .emailerr').hide();
            }
            if (email == '' && phone == '') {
                empty = false;
                $('#' + data_form_id + ' .contacterr').css('display', 'block');
            } else {
                $('#' + data_form_id + ' .contacterr').hide()
                $('#' + data_form_id + ' .emailerr').hide()
                //check email format
                if (email != '') {
                    if (isEmail(email) == false) {
                        empty = false;
                        $('#' + data_form_id + ' .emailerr').css('display', 'block');
                    } else {
                        $('#' + data_form_id + ' .emailerr').hide();
                    }
                }
            }
            if (empty == true) {
                jQuery('#' + data_button_id).click();
            } else {
                return false;
            }
        });
        $('.onSubmitSingle').click(function(e) {
            var empty = true;
            var data_form_id = $(this).attr('data-id');
            var data_button_id = $(this).attr('data-button-id');
            var email = $('#' + data_form_id + ' input[name="email"]').val();
            if (email == '') {
                empty = false;
                $('#' + data_form_id + ' .contacterr').css('display', 'block');
                $('#' + data_form_id + ' .emailerr').hide()

            } else if (email != '') {
                if (isEmail(email) == false) {
                    empty = false;
                    $('#' + data_form_id + ' .emailerr').show();
                    $('#' + data_form_id + ' .contacterr').hide()

                } else {
                    $('#' + data_form_id + ' .emailerr').hide();
                    $('#' + data_form_id + ' .contacterr').hide()
                }
            }
            if (empty == true) {
                jQuery('#' + data_button_id).click();
            } else {
                return false;
            }
        });
    });

    $(document).ready(function() {
        $(window).keydown(function(event) {
            if (event.keyCode == 13) {
                event.preventDefault();
                return false;
            }
        });
    });
</script>
</body>


</html>
