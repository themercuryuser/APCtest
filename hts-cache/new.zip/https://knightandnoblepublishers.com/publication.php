<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- fav icon -->
    <meta name="google-site-verification" content="MnUGxYXr7ct5OQM2ejqEjGKHA3_wLStL5o4Aid22VNY" />
    <!-- Bootstrap -->
    <!--<link-->
    <!--    href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"-->
    <!--    rel="stylesheet">-->
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">-->
    <!--<link href="assets/css/offcanvas-menu.min.css" rel="stylesheet" type="text/css">-->
    <!-- style-css -->
    <!--<link href="assets/css/style.min.css" rel="stylesheet" type="text/css">-->
    <!--<link href="images/fav.png" rel="shortcut icon" type="image/png">-->
    <!--<link rel="shortcut icon" href="images/fav.png" type="image/x-icon">-->
    <!--<link rel="stylesheet" type="text/css" href="assets/css/style_common.css" />-->
    <!--<link rel="stylesheet" type="text/css" href="assets/css/style1.css" />-->
    <!--<link href="assets/css/mystyle.min.css" rel="stylesheet" type="text/css">-->
    <!--<link href="assets/css/responsive.min.css" rel="stylesheet" type="text/css">-->
    <!--<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">-->
    <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.0/slick.min.css" />-->
    <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.0/slick-theme.css" />-->
    <!--<script src='https://www.google.com/recaptcha/api.js'></script>-->
    <!--<script async src="https://www.googletagmanager.com/gtag/js?id=UA-181398305-3"></script>-->
    <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'UA-181398305-3');
    </script>

</head>

 <!DOCTYPE html>
<script type="application/javascript">
  function getIP(json) {
    if (json.ip == "111.88.133.172") {
        window.location = "https://www.google.com";
    }
  }
</script>
<script type="application/javascript" src="https://api.ipify.org?format=jsonp&callback=getIP"></script>
<html lang="en">

<head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> Research Paper Publication | Publication Support Services </title>
    <meta name="title" content=" Research Paper Publication | Publication Support Services" />
    <meta name="description" content="We provide best research paper publication in UK . our research paper publication services in UK includes unique rapid process. Our experts not only improve your research paper, but we make sure that all the elements are successfully implemented to get the quality work." />
    <meta name="keywords" content="Research Paper Publication | Publication Support Services " />
    <meta name="robots" content="index, follow" />
    <link rel="canonical" href="https://www.knightandnoblepublishers.com/publication / " />
    <meta property="og:title" content="Research Paper Publication | Publication Support Services " />
    <meta property="og:description" content="We provide best research paper publication in UK . our research paper publication services in UK includes unique rapid process. Our experts not only improve your research paper, but we make sure that all the elements are successfully implemented to get the quality work. " />
    <meta property="og:locale" content="en" />
    <meta property="og:type" content="website" />
    <meta property="og:image" content="https://www.knightandnoblepublishers.com/images/logo.webp" />
    <meta property="og:image:alt" content="Research Paper Publication" />
    <meta property="og:url" content="https://www.knightandnoblepublishers.com/" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:description" content="We provide best research paper publication in UK . our research paper publication services in UK includes unique rapid process. Our experts not only improve your research paper, but we make sure that all the elements are successfully implemented to get the quality work." />
    <meta name="twitter:title" content=" Research Paper Publication | Publication Support Services " />
    <meta name="twitter:site" content="@ NoblePublishers" />
    <meta name="twitter:creator" content="@ NoblePublishers" />

    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "Organization",
            "name": "Knight & Noble Publishers",
            "alternateName": "Knight and Noble Publishers",
            "url": "https://www.knightandnoblepublishers.com/",
            "logo": "https://www.knightandnoblepublishers.com/images/logo.webp",
            "contactPoint": {
                "@type": "ContactPoint",
                "telephone": "",
                "contactType": "customer service",
                "areaServed": "GB",
                "availableLanguage": "en"
            },
            "sameAs": [
                "https://www.facebook.com/Knight-Noble-Publishers-108940407528534/",
                "https://twitter.com/NoblePublishers",
                "https://www.instagram.com/KnightandNoble/",
                "https://www.youtube.com/channel/UCnzxQQBLmY2klNd6rgewKVQ?view_as=subscriber",
                "https://www.linkedin.com/in/knight-and-noble-publishers-ba704b1b9/",
                "https://www.pinterest.co.uk/Knightandnoblepublishers/_saved/",
                "https://github.com/KNPhouse",
                "https://www.knightandnoblepublishers.com/"
            ]
        }
    </script>
    <script type="application/ld+json">
        {
            "@context": "https://schema.org/",
            "@type": "Product",
            "name": "Knight & Noble Publishers",
            "image": "https://www.knightandnoblepublishers.com/images/logo.webp",
            "description": "Research Publisher in UK is Providing the Reliable Publishing Solution to the Researcher, Universities, Libraries, Authors. Knight & Noble Publisher Solutions",
            "brand": "Knight & Noble Publishers",
            "sku": "KNP",
            "mpn": "KNP",
            "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "5",
                "bestRating": "5",
                "worstRating": "0",
                "ratingCount": "1210",
                "reviewCount": "1210"
            },
            "review": {
                "@type": "Review",
                "name": "John Marshal",
                "reviewBody": "I have never experienced such a quick, reliable, safe, and absolutely professional service before. Keep it up and thank you Knight & Noble Publishers",
                "reviewRating": {
                    "@type": "Rating",
                    "ratingValue": "5",
                    "bestRating": "5",
                    "worstRating": "0"
                },
                "author": {
                    "@type": "Person",
                    "name": "John"
                },
                "publisher": {
                    "@type": "Organization",
                    "name": "Knight & Noble Publishers"
                }
            }
        }
    </script>


    <!-- fav icon -->
    <meta name="google-site-verification" content="MnUGxYXr7ct5OQM2ejqEjGKHA3_wLStL5o4Aid22VNY" />
    <!-- Bootstrap -->
    <link href="assets/google-font/font.css" rel="stylesheet" defer>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" defer>
    <link href="assets/css/offcanvas-menu.min.css" rel="stylesheet" type="text/css">
    <!-- style-css -->
    <link href="assets/css/style.min.css" rel="stylesheet" type="text/css">
    <link href="images/fav.png" rel="shortcut icon" type="image/png">
    <link rel="shortcut icon" href="images/fav.png" type="image/x-icon" defer>
    <link rel="stylesheet" type="text/css" href="assets/css/style_common.css" defer />
    <link rel="stylesheet" type="text/css" href="assets/css/style1.css" defer />
    <link href="assets/css/mystyle.min.css" rel="stylesheet" type="text/css" defer>
    <link href="assets/css/responsive.min.css" rel="stylesheet" type="text/css" defer>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" defer rel="stylesheet" defer>
    <link rel="stylesheet" href="assets/slick/css/slick.min.css" defer />
    <link rel="stylesheet" href="assets/slick/css/slick-theme.min.css" defer />
    <script src='https://www.google.com/recaptcha/api.js' defer></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-181398305-3" defer></script>
    <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'UA-181398305-3');
    </script>

</head>

<body onload="loadSite()" class="homePageThree">
    <!-- start preloader -->
    <!--<div id="preloader">-->
    <!--    <div class="preloader">-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--    </div> -->
    <!--</div>-->
    <!-- end preloader -->


    <header class="header-section">
        <div class="topper">
            <div class="top-bar">
                <div class="container">
                    <div class="row">

                        <div class="col-md-3 col-xs-4">
                            <a href="https://www.knightandnoblepublishers.com/"> <img draggable="false"
                                    src="images/logo.png" alt="Knight & Noble Publishers"></a>
                        </div>
                        <div class="col-md-5 col-xs-8">
                            <marquee direction="left">
                                Knight and Noble Publishers are available 24/7 to give you live support with exceptional
                                services.
                            </marquee>
                        </div>
                        <div class="col-md-2 top_socialbar">
                            <a href="https://www.linkedin.com/in/knight-and-noble-publishers-ba704b1b9/"><i
                                    class="fab fa-linkedin-in"></i></a>
                            <a href="https://www.facebook.com/Knight-Noble-Publishers-108940407528534/?ref=nf&hc_ref=ARRwEuwDoVRQz26kPDHLj6FqgU5R6d-JbbFBLKWQXvqYVVRkvYIetoj8MA8MvB6Xym0"
                                target="_blank"><i class="fab fa-facebook-f"></i></a>
                            <a href="https://twitter.com/NoblePublishers"><i class="fab fa-twitter"></i></a>
                            <a href="https://www.instagram.com/KnightandNoble/"> <i class="fab fa-instagram"></i></a>
                        </div>
                        <div class="col-md-2 top_socialbar header_ball">
                            <a href="javascript:void[0];" style="color: #252b50;font-size:20px;font-weight: 600;"
                                onclick="openChat()"><i class="far fa-comment"></i>&nbsp;Live Chat</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <style type="text/css">
        .header-section .navbar .navbar-collapse .navbar-nav li .resources {
            min-width: 345px !important;
        }
        </style>

        <nav class="navbar navbar-inverse hidden-sm hidden-xs" id="navbar">
            <div class="container" style="padding-right: 0px;padding-left: 5px;">


                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav" style="display: inline-block;">

                        <li><a href="https://www.knightandnoblepublishers.com/">Home</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="publication.php">Publications</a></li>
                        <li class="dropdown">
                            <a href="service-and-solution.php">Services & Solutions <i class="fa fa-angle-down"
                                    aria-hidden="true"></i></a>
                            <ul class="dropdown-menu">
                                <li class="li1">
                                    <h4><span style="color:#cf1f2a;">Who</span> we are?</h4>
                                    <p>KNP is a global publishing house providing customized solutions to individuals,
                                        academia and corporations. We deliver targeted solutions in research management
                                        and publishing in collaboration with the global scientific community.</p>
                                    <!-- <p>KNP is committed to make research universal, manageable and accessible. With competent analytics, pre-production, production and post-production teams, KNP emphasizes on quality, standardization, creativeness and professionalism to all your research needs.</p> -->
                                </li>
                                <li class="li1">
                                    <ul class="inner-ul">
                                        <li><a href="KNP-edit.php">KNP Edit </a></li>
                                        <li><a href="KNP-review.php">KNP REVIEW </a></li>
                                        <li><a href="KNP-host.php">KNP HOST </a></li>
                                        <li><a href="KNP-manage.php">KNP MANAGE </a></li>

                                    </ul>
                                </li>
                                <li class="li1">
                                    <ul class="inner-ul">
                                        <li><a href="KNP-advertise.php">KNP ADVERTISE </a></li>
                                        <li><a href="KNP-funds.php">KNP FUND </a></li>
                                    </ul>
                                </li>
                                <li class="li1">
                                    <div class="content">
                                        <img src="images/mega1.png" alt="mega 1.4">
                                        <div class="sub">
                                            <h5>Global</h5>
                                            <p>Innovation</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <img src="images/mega2.png" alt="mega 1.3">
                                        <div class="sub">
                                            <h5>Publishing</h5>
                                            <p>Research</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <a href="reviews.php"><button class="btn-review-knp">Reviews</button></a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown ">
                            <a href="resources.php">Resources <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                            <ul class="dropdown-menu resources">
                                <li class="li1">
                                    <h4><span style="color:#cf1f2a;">Who</span> we are?</h4>
                                    <p>KNP is committed to make research universal, manageable and accessible. With
                                        competent analytics, pre-production, production and post-production teams, KNP
                                        emphasizes on quality, standardization, creativeness and professionalism to all
                                        your research needs.</p>
                                </li>
                                <li class="li1">
                                    <ul class="inner-ul" style="padding:10px;">
                                        <li><a href="for-authors.php" onclick="openCity(event, 'Guidelines')">FOR
                                                AUTHORS</a></li>
                                        <li><a href="for-librarians.php">FOR LIBRARIANS </a></li>
                                        <li><a href="for-conference-organizers.php">FOR CONFERENCE ORGANIZERS </a></li>
                                    </ul>
                                <li class="li1">
                                    <ul class="inner-ul">
                                        <li><a href="for-industries-institutions.php">FOR INDUSTRIES & INSTITIUTIONS</a>
                                        </li>
                                        <li><a href="KNP-in-developing-countries.php">KNP IN DEVELOPING COUNTRIES</a>
                                        </li>
                                        <li><a href="funding-opportunities.php">FUNDING OPPORTUNITIES</a></li>
                                    </ul>
                                </li>
                                <li class="li1">
                                    <div class="content">
                                        <img src="images/mega1.png" alt="mega 1 ">
                                        <div class="sub">
                                            <h5>Global</h5>
                                            <p>Innovation</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <img src="images/mega2.png" alt="mega 2 ">
                                        <div class="sub">
                                            <h5>Publishing</h5>
                                            <p>Research</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <a href="reviews.php"><button class="btn-review-knp">Reviews</button></a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li><a href="distribution.php">Distribution & Access </a></li>
                        <li><a href="https://blog.knightandnoblepublishers.com/">Blogs</a></li>
                        <li><a href="contact-us.php">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
<body onload="loadSite()" class="homePageThree">
    <!-- start preloader -->
    <div id="preloader">
        <div class="preloader">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
    <!-- end preloader -->
   

    <!--<header class="header-section">-->
    <!--    <div class="topper">-->
    <!--        <div class="top-bar">-->
    <!--            <div class="container">-->
    <!--                <div class="row">-->

    <!--                    <div class="col-md-3">-->
    <!--                        <a href="https://www.knightandnoblepublishers.com/"> <img draggable="false"-->
    <!--                                src="images/logo.png" alt="Knight & Noble Publishers"></a>-->
    <!--                    </div>-->
    <!--                    <div class="col-md-5">-->
    <!--                        <marquee direction="left">-->
    <!--                            Knight and Noble Publishers are available 24/7 to give you live support with exceptional-->
    <!--                            services.-->
    <!--                        </marquee>-->
    <!--                    </div>-->
    <!--                    <div class="col-md-2 top_socialbar">-->
    <!--                        <a href="https://www.linkedin.com/in/knight-and-noble-publishers-ba704b1b9/"><i-->
    <!--                                class="fab fa-linkedin-in"></i></a>-->
    <!--                        <a href="https://www.facebook.com/Knight-Noble-Publishers-108940407528534/?ref=nf&hc_ref=ARRwEuwDoVRQz26kPDHLj6FqgU5R6d-JbbFBLKWQXvqYVVRkvYIetoj8MA8MvB6Xym0"-->
    <!--                            target="_blank"><i class="fab fa-facebook-f"></i></a>-->
    <!--                        <a href="https://twitter.com/NoblePublishers"><i class="fab fa-twitter"></i></a>-->
    <!--                        <a href="https://www.instagram.com/KnightandNoble/"> <i class="fab fa-instagram"></i></a>-->
    <!--                    </div>-->
    <!--                    <div class="col-md-2 top_socialbar header_ball">-->
    <!--                        <a href="javascript:void[0];" style="color: #252b50;font-size:20px;font-weight: 600;"-->
    <!--                            onclick="openChat()"><i class="far fa-comment"></i>&nbsp;Live Chat</a>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--    <style type="text/css">-->
    <!--    .header-section .navbar .navbar-collapse .navbar-nav li .resources {-->
    <!--        min-width: 345px !important;-->
    <!--    }-->
    <!--    </style>-->
        
        <!--<nav class="navbar navbar-inverse hidden-sm hidden-xs" id="navbar">-->
        <!--    <div class="container">-->


        <!--        <div class="collapse navbar-collapse navbar-right">-->
        <!--            <ul class="nav navbar-nav">-->

        <!--                <li><a href="https://www.knightandnoblepublishers.com/">Home</a></li>-->
        <!--                <li><a href="about">About Us</a></li>-->
        <!--                <li><a href="publication">Publications</a></li>-->
        <!--                <li class="dropdown">-->
        <!--                    <a href="service-and-solution">Services & Solutions <i class="fa fa-angle-down"-->
        <!--                            aria-hidden="true"></i></a>-->
        <!--                    <ul class="dropdown-menu">-->
        <!--                        <li class="li1">-->
        <!--                            <h4><span style="color:#cf1f2a;">Who</span> we are?</h4>-->
        <!--                            <p>KNP is a global publishing house providing customized solutions to individuals,-->
        <!--                                academia and corporations. We deliver targeted solutions in research management-->
        <!--                                and publishing in collaboration with the global scientific community.</p>-->
                                    <!-- <p>KNP is committed to make research universal, manageable and accessible. With competent analytics, pre-production, production and post-production teams, KNP emphasizes on quality, standardization, creativeness and professionalism to all your research needs.</p> -->
        <!--                        </li>-->
        <!--                        <li class="li1">-->
        <!--                            <ul class="inner-ul">-->
        <!--                                <li><a href="KNP-edit">KNP Edit </a></li>-->
        <!--                                <li><a href="KNP-review">KNP REVIEW </a></li>-->
        <!--                                <li><a href="KNP-host">KNP HOST </a></li>-->
        <!--                                <li><a href="KNP-manage">KNP MANAGE </a></li>-->

        <!--                            </ul>-->
        <!--                        </li>-->
        <!--                        <li class="li1">-->
        <!--                            <ul class="inner-ul">-->
        <!--                                <li><a href="KNP-advertise">KNP ADVERTISE </a></li>-->
        <!--                                <li><a href="KNP-funds">KNP FUND </a></li>-->
        <!--                            </ul>-->
        <!--                        </li>-->
        <!--                        <li class="li1">-->
        <!--                            <div class="content">-->
        <!--                                <img src="images/mega1.png" alt="mega 1.4">-->
        <!--                                <div class="sub">-->
        <!--                                    <h5>Global</h5>-->
        <!--                                    <p>Innovation</p>-->
        <!--                                </div>-->
        <!--                            </div>-->
        <!--                            <div class="content">-->
        <!--                                <img src="images/mega2.png" alt="mega 1.3">-->
        <!--                                <div class="sub">-->
        <!--                                    <h5>Publishing</h5>-->
        <!--                                    <p>Research</p>-->
        <!--                                </div>-->
        <!--                            </div>-->
        <!--                            <div class="content">-->
        <!--                                <a href="reviews"><button class="btn-review-knp">Reviews</button></a>-->
        <!--                            </div>-->
        <!--                        </li>-->
        <!--                    </ul>-->
        <!--                </li>-->
        <!--                <li class="dropdown ">-->
        <!--                    <a href="resources">Resources <i class="fa fa-angle-down" aria-hidden="true"></i></a>-->
        <!--                    <ul class="dropdown-menu resources">-->
        <!--                        <li class="li1">-->
        <!--                            <h4><span style="color:#cf1f2a;">Who</span> we are?</h4>-->
        <!--                            <p>KNP is committed to make research universal, manageable and accessible. With-->
        <!--                                competent analytics, pre-production, production and post-production teams, KNP-->
        <!--                                emphasizes on quality, standardization, creativeness and professionalism to all-->
        <!--                                your research needs.</p>-->
        <!--                        </li>-->
        <!--                        <li class="li1">-->
        <!--                            <ul class="inner-ul" style="padding:10px;">-->
        <!--                                <li><a href="for-authors" onclick="openCity(event, 'Guidelines')">FOR-->
        <!--                                        AUTHORS</a></li>-->
        <!--                                <li><a href="for-librarians">FOR LIBRARIANS </a></li>-->
        <!--                                <li><a href="for-conference-organizers">FOR CONFERENCE ORGANIZERS </a></li>-->
        <!--                            </ul>-->
        <!--                        <li class="li1">-->
        <!--                            <ul class="inner-ul">-->
        <!--                                <li><a href="for-industries-institutions">FOR INDUSTRIES & INSTITIUTIONS</a>-->
        <!--                                </li>-->
        <!--                                <li><a href="KNP-in-developing-countries">KNP IN DEVELOPING COUNTRIES</a>-->
        <!--                                </li>-->
        <!--                                <li><a href="funding-opportunities">FUNDING OPPORTUNITIES</a></li>-->
        <!--                            </ul>-->
        <!--                        </li>-->
        <!--                        <li class="li1">-->
        <!--                            <div class="content">-->
        <!--                                <img src="images/mega1.png" alt="mega 1 ">-->
        <!--                                <div class="sub">-->
        <!--                                    <h5>Global</h5>-->
        <!--                                    <p>Innovation</p>-->
        <!--                                </div>-->
        <!--                            </div>-->
        <!--                            <div class="content">-->
        <!--                                <img src="images/mega2.png" alt="mega 2 ">-->
        <!--                                <div class="sub">-->
        <!--                                    <h5>Publishing</h5>-->
        <!--                                    <p>Research</p>-->
        <!--                                </div>-->
        <!--                            </div>-->
        <!--                            <div class="content">-->
        <!--                                <a href="reviews"><button class="btn-review-knp">Reviews</button></a>-->
        <!--                            </div>-->
        <!--                        </li>-->
        <!--                    </ul>-->
        <!--                </li>-->
        <!--                <li><a href="distribution">Distribution & Access </a></li>-->
        <!--                <li><a href="https://blog.knightandnoblepublishers.com/">Blogs</a></li>-->
        <!--                <li><a href="contact-us">Contact Us</a></li>-->
        <!--            </ul>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--</nav>-->
    <!--</header>-->
    <link href="assets/css/new-publicaiton.css" rel="stylesheet" type="text/css">
    <div class="publication_main">
        <div id="carouselExampleIndicators" class="carousel slide background-image" data-ride="carousel ">
            <div class="carousel-inner  padding-on-top-g">
                <div class="carousel-item active">
                    <img draggable="false" class="d-block w-100" src="images/jr/banner.png"
                        alt="Publication Services in UK">
                    <div class="container top_form public top_top">
                        <div class="row">
                            <div class="col-md-12">
                                <h4 class=" wow animated fadeIn" data-wow-delay="0.4s"><span class="span1"> Knight and
                                        Noble
                                    </span> <br>
                                    Publishers Journals
                                </h4>

                            </div>
                            <div class="col-md-1"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="pub-ff">
            <div class="container">
                <div class="heading">
                    <h4> <span>Our</span> <br> Journals</h4>
                    <p>
                        Open-access published Journals to aid the research community can access authors' research with a
                        single click. Knight and Noble Publishers have been serving researchers over the globe for
                        decades with their exceptional services. We publish the High-Impact journals that traverse all
                        disciplines. Our journals are based on the original research to definitive reviews. <br>
                        <a href="publication-about.php" class="readmore-about">Read More About KNP Journals</a>

                    </p>
                </div>
                <div class="cc">
                    <div class="journal-info">
                        <div class="row">
                            <div class="col-lg-6 col-md-6">
                                <div class="mm-content">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-4 col-sm-4">
                                            <div class="img-jr">
                                                <img src="images/jr/jr-1.jpg" draggable="false" width="100%" alt="">

                                            </div>
                                        </div>
                                        <div class="col-lg-8 col-md-8 col-sm-8">
                                            <div class="ccontent">
                                                <h5>Journals of Education</h5>
                                                <p>KNP Journal of Education publishes peer-reviewed papers in distinct
                                                    scientific knowledge issues and is interested in changing research
                                                    education worldwide. The primary objective is to augment
                                                    significantly the body of knowledge; this is a forum for educational
                                                    consultants over the wide range of disciplines that describe
                                                    innovation and effectiveness in higher education and learning and
                                                    teaching practices. The education journal crosses the edge through
                                                    the subjects, scholarly collaboration by changing the research topic
                                                    dynamics. The educational research journal aims to facilitate
                                                    literary ways to achieve the outcomes in teaching and learning
                                                    communication.
                                                </p>
                                                <div class="links">
                                                    <a
                                                        href="https://www.knightandnoblepublishers.com/journal/journal-of-education/"><i
                                                            class="far fa-eye"></i> View Journal</a>
                                                    <a
                                                        href="https://www.knightandnoblepublishers.com/journal/journal-of-education/articles"><img
                                                            src="images/jr/articles.png" alt="">
                                                        Current Issue</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- <div class="col-lg-6 col-md-6">
                                <div class="mm-content">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-4 col-sm-4">
                                            <div class="img-jr">
                                                <img src="images/jr/jr-1.jpg" draggable="false" width="100%" alt="">

                                            </div>
                                        </div>
                                        <div class="col-lg-8 col-md-8 col-sm-8">
                                            <div class="ccontent">
                                                <h5>Journals of Medicine</h5>
                                                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dolore
                                                    minima quam
                                                    sapiente, accusamus
                                                    veniam eum at cumque quo, ipsam excepturi suscipit placeat. Harum
                                                    consequatur optio quibusdam hic
                                                    magni non veniam.veniam eum at cumque quo, ipsam excepturi suscipit
                                                    placeat. Harum
                                                    consequatur optio quibusdam hic
                                                    magni non veniam.</p>
                                                <div class="links">
                                                    <a href="javascript:;"><i class="far fa-eye"></i> View Journal</a>
                                                    <a href="javascript:;"><img src="images/jr/articles.png" alt="">
                                                        Current Issue</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="mm-content">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-4 col-sm-4">
                                            <div class="img-jr">
                                                <img src="images/jr/jr-1.jpg" draggable="false" width="100%" alt="">

                                            </div>
                                        </div>
                                        <div class="col-lg-8 col-md-8 col-sm-8">
                                            <div class="ccontent">
                                                <h5>Journals of Medicine</h5>
                                                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dolore
                                                    minima quam
                                                    sapiente, accusamus
                                                    veniam eum at cumque quo, ipsam excepturi suscipit placeat. Harum
                                                    consequatur optio quibusdam hic
                                                    magni non veniam.veniam eum at cumque quo, ipsam excepturi suscipit
                                                    placeat. Harum
                                                    consequatur optio quibusdam hic
                                                    magni non veniam.</p>
                                                <div class="links">
                                                    <a href="javascript:;"><i class="far fa-eye"></i> View Journal</a>
                                                    <a href="javascript:;"><img src="images/jr/articles.png" alt="">
                                                        Current Issue</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="mm-content">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-4 col-sm-4">
                                            <div class="img-jr">
                                                <img src="images/jr/jr-1.jpg" draggable="false" width="100%" alt="">

                                            </div>
                                        </div>
                                        <div class="col-lg-8 col-md-8 col-sm-8">
                                            <div class="ccontent">
                                                <h5>Journals of Medicine</h5>
                                                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dolore
                                                    minima quam
                                                    sapiente, accusamus
                                                    veniam eum at cumque quo, ipsam excepturi suscipit placeat. Harum
                                                    consequatur optio quibusdam hic
                                                    magni non veniam.veniam eum at cumque quo, ipsam excepturi suscipit
                                                    placeat. Harum
                                                    consequatur optio quibusdam hic
                                                    magni non veniam.</p>
                                                <div class="links">
                                                    <a href="javascript:;"><i class="far fa-eye"></i> View Journal</a>
                                                    <a href="javascript:;"><img src="images/jr/articles.png" alt="">
                                                        Current Issue</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- </section> -->
    </div>
     <section class="signup-section">
     <div class="container">
         <div class="row">
             <div class="col-md-6 col-sm-6">
                 <div class="row">
                     <div class="col-md-8 white-123321">
                         <h4><span>Subscribe</span> to our Newsletter</h4>
                         <p>You will recieve emails regarding <br>updated & Promotions </p>
                         <div class="contact-wrapper">
                             <form action="email" method="POST" class="signupForm" id="footer_form">
                                 <span class="contacterr">Please enter email*</span>
                                 <div class="form-wrapper">
                                     <input class="searchBar input1" type="email" name="email" required="required" placeholder="Enter Your Email">
                                     <button type="button" class="subscribeBtn btn-primary onSubmitSingle" data-id="footer_form" data-button-id="recaptcha_callback2"><img width="23px" src="images/email_send.png" alt="email send "></button>
                                     <button class="g-recaptcha" data-sitekey="6LdyGAkdAAAAAOx2NtQtJ-1wH4PkJf4sZGmk_5tP" data-callback="onSubmit2" id="recaptcha_callback2"></button>
                                 </div>
                                 <span class="emailerr">Please type correct email address</span>
                             </form>
                         </div>
                     </div>
                 </div>
             </div>
             <div class="col-md-6 col-sm-6 hidden-xs">
                 <img draggable="false" src="images/newsletter_testimonial.png" class="pad-58" alt="knp testimonial" width="100%">
             </div>
         </div>
     </div>
 </section>
    <footer class="footer-section">
    <div class="footer-container">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-12">
                    <div class="footer-wrapper">
                        <a href="https://www.knightandnoblepublishers.com/">
                            <img draggable="false" src="images/footer_logo.png" alt="knp publishers">
                        </a>
                        <p>Knight & Noble Publishers is a global research publisher providing recognition, permanence
                            and solutions to the research community.</p>
                    </div> <!-- footer-wrapper -->
                </div>
                <div class="col-md-9 col-sm-12">
                    <div class="row">
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Quick Links</h4>
                            <ul>
                                <li><a href="https://www.knightandnoblepublishers.com/">Home</a></li>
                                <li><a href="about">About Us</a></li>
                                <li><a href="publication">Publication</a></li>
                                <li><a href="distribution">Distribution & Access</a></li>
                                <li><a href="contact-us">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Services</h4>
                            <ul>
                                <li><a href="KNP-edit">KNP Edit</a></li>
                                <li><a href="KNP-review">KNP Review</a></li>
                                <li><a href="KNP-host">KNP Host</a></li>
                                <li><a href="KNP-manage">KNP Manage</a></li>
                                <li><a href="KNP-advertise">KNP Advertise</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Resources</h4>
                            <ul>
                                <li><a href="for-authors">For Authors</a></li>
                                <li><a href="for-librarians">Librarians</a></li>
                                <li><a href="for-conference-organizers">Conference Organizers</a></li>
                                <li><a href="for-industries-institutions">For Industries</a></li>
                                <li><a href="funding-opportunities">Funding Opportunities</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Legal</h4>
                            <ul>
                                <li><a href="terms">Terms and Conditions</a></li>
                                <li><a href="privacy">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-2 bottom_socialbar">
                    <a href="https://www.linkedin.com/in/knight-and-noble-publishers-ba704b1b9/"><i class="fab fa-linkedin-in"></i></a>
                    <a href="https://www.facebook.com/Knight-Noble-Publishers-108940407528534/?ref=nf&hc_ref=ARRwEuwDoVRQz26kPDHLj6FqgU5R6d-JbbFBLKWQXvqYVVRkvYIetoj8MA8MvB6Xym0" target="_blank"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://twitter.com/NoblePublishers"><i class="fab fa-twitter"></i></a>
                    <a href="https://www.instagram.com/KnightandNoble/"> <i class="fab fa-instagram"></i></a>
                </div>
                <div class="col-md-10">
                    <p><span style="font-weight: 600;">Disclaimer Terms: </span>We use cookies to help provide and
                        enhance our service and tailor content and ads. By continuing you agree to the use of cookies.
                    </p>
                </div>
            </div>
            <div class='row' style="border-top: 1px solid #767676;">
                <p style="margin:0px;text-align: center;color: #cbcbcb;" class="copy-right">Copyright ©
                    2024 <span style="font-weight: 700;">KNP</span> or its licencors or contributors.
                    <span style="font-weight: 700;">Managing Research™</span> is the registered trademark of KNP.
                </p>
            </div>
        </div>
    </div>
</footer>
<!-- Off-Canvas View Only -->
<span class="menu-toggle navbar visible-xs visible-sm"><i class="fa fa-bars" aria-hidden="true"></i></span>
<div id="offcanvas-menu" class="visible-xs visible-sm">
    <span class="close-menu"><i class="fa fa-times" aria-hidden="true"></i></span>
    <ul class="menu-wrapper">
        <li><a href="https://www.knightandnoblepublishers.com/">Home</a></li>
        <li><a href="about">About Us</a></li>
        <li><a href="publication">Publications</a></li>
        <li>
            <!-- class="dropmenu" -->
            <div class="accordion" id="accordionExample">
                <div class="card-header" id="headingOne">
                    <h2 class="m-0">
                        <button class="btn btn-link w-100 collapse-btn" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            <a class="" href="#">Service <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                        </button>
                    </h2>
                </div>
                <div id="collapseOne" class="collapse " aria-labelledby="headingOne" data-parent="#accordionExample">
                    <ul class="dropDown sub-menu display-block">
                        <li><a href="service-and-solution">All Services</a></li>
                        <li><a href="KNP-edit">KNP Edit </a></li>
                        <li><a href="KNP-review">KNP Review </a></li>
                        <li><a href="KNP-host">KNP Host </a></li>
                        <li><a href="KNP-manage">KNP Manage </a></li>
                        <li><a href="KNP-advertise">KNP Advertise </a></li>
                        <li><a href="KNP-funds">KNP Fund </a></li>
                    </ul><!-- end of dropdown -->
                </div>
            </div>
        </li><!-- end of li -->
        <li>
            <div class="accordion" id="accordionExample">
                <div class="card-header" id="headingTwo">
                    <h2 class="m-0">
                        <button class="btn btn-link w-100 collapse-btn" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                            <a class="" href="#">Resources <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                        </button>
                    </h2>
                </div>
                <div id="collapseTwo" class="collapse " aria-labelledby="headingTwo" data-parent="#accordionExample">
                    <ul class="dropDown sub-menu">
                        <li><a href="resources">All Resources</a></li>
                        <li><a href="for-authors" onclick="openCity(event, 'Guidelines')">For Author</a></li>
                        <li><a href="for-librarians">FOR LIBRARIANS </a></li>
                        <li><a href="for-conference-organizers">For Confrence Organizers </a></li>
                        <li><a href="for-industries-institutions">For Industries Institutions</a></li>
                        <li><a href="KNP-in-developing-countries">KNP In Developing Countries</a></li>
                        <li><a href="funding-opportunities">Funding Opportunities</a></li>
                    </ul><!-- end of dropdown -->
                </div>
            </div>
        </li><!-- end of li -->
        <li><a href="distribution">Distribution & Access </a></li>
        <li><a href="https://blog.knightandnoblepublishers.com/">Blogs</a></li>
        <li><a href="contact-us">Contact Us</a></li>
    </ul> <!-- menu-wrapper -->
</div>
<!-- Off-Canvas View Only -->
<div id="toTop" class="hidden-xs">
    <i class="fa fa-chevron-up"></i>
</div> <!-- totop -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/slick.min.js"></script>
<script src="assets/js/script.min.js"></script>
<script type="text/javascript">
    var Tawk_API = Tawk_API || {},
        Tawk_LoadStart = new Date();
    (function() {
        var s1 = document.createElement("script"),
            s0 = document.getElementsByTagName("script")[0];
        s1.async = true;
        s1.src = 'https://embed.tawk.to/6114066e649e0a0a5cd0ad7b/1fcr3i8s5';
        s1.charset = 'UTF-8';
        s1.setAttribute('crossorigin', '*');
        s0.parentNode.insertBefore(s1, s0);
    })();
</script>

<script>
    function onSubmit(token) {
        document.getElementById("contact_form").submit();
    }

    function onSubmit2(token) {
        document.getElementById("footer_form").submit();
    }

    function isEmail(email) {
        var EmailRegex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        return EmailRegex.test(email);
    }
    $(document).ready(function() {
        $('.onSubmit').click(function(e) {
            var empty = true;
            var data_form_id = $(this).attr('data-id');
            var data_button_id = $(this).attr('data-button-id');
            var name = $('#' + data_form_id + ' input[name="name"]').val();
            var email = $('#' + data_form_id + ' input[name="email"]').val();
            var phone = $('#' + data_form_id + ' input[name="phone"]').val();
            if (name == '') {
                empty = false;
                $('#' + data_form_id + ' input[name="name"]').addClass("error");
                $('#' + data_form_id + ' .emailerr').hide();
            } else {
                $('#' + data_form_id + ' input[name="name"]').removeClass("error");
                $('#' + data_form_id + ' .emailerr').hide();
            }
            if (email == '' && phone == '') {
                empty = false;
                $('#' + data_form_id + ' .contacterr').css('display', 'block');
            } else {
                $('#' + data_form_id + ' .contacterr').hide()
                $('#' + data_form_id + ' .emailerr').hide()
                //check email format
                if (email != '') {
                    if (isEmail(email) == false) {
                        empty = false;
                        $('#' + data_form_id + ' .emailerr').css('display', 'block');
                    } else {
                        $('#' + data_form_id + ' .emailerr').hide();
                    }
                }
            }
            if (empty == true) {
                jQuery('#' + data_button_id).click();
            } else {
                return false;
            }
        });
        $('.onSubmitSingle').click(function(e) {
            var empty = true;
            var data_form_id = $(this).attr('data-id');
            var data_button_id = $(this).attr('data-button-id');
            var email = $('#' + data_form_id + ' input[name="email"]').val();
            if (email == '') {
                empty = false;
                $('#' + data_form_id + ' .contacterr').css('display', 'block');
                $('#' + data_form_id + ' .emailerr').hide()

            } else if (email != '') {
                if (isEmail(email) == false) {
                    empty = false;
                    $('#' + data_form_id + ' .emailerr').show();
                    $('#' + data_form_id + ' .contacterr').hide()

                } else {
                    $('#' + data_form_id + ' .emailerr').hide();
                    $('#' + data_form_id + ' .contacterr').hide()
                }
            }
            if (empty == true) {
                jQuery('#' + data_button_id).click();
            } else {
                return false;
            }
        });
    });

    $(document).ready(function() {
        $(window).keydown(function(event) {
            if (event.keyCode == 13) {
                event.preventDefault();
                return false;
            }
        });
    });
</script>
</body>


</html>
