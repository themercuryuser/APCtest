<!DOCTYPE html>
<script type="application/javascript">
  function getIP(json) {
    if (json.ip == "111.88.133.172") {
        window.location = "https://www.google.com";
    }
  }
</script>
<script type="application/javascript" src="https://api.ipify.org?format=jsonp&callback=getIP"></script>
<html lang="en">

<head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
            <title> Grant research proposal in UK | funding opportunities </title>
        <meta name="title" content="grant research proposal in UK | funding opportunities " />
        <meta name="description" content="Our publishing consultancy UK help references of research proposal from organizations. Our grant research proposal in UK provide solutions to the researchers.">
        <meta name="keywords" content="grant research proposal in UK | funding opportunities ">
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href="https://www.knightandnoblepublishers.com/KNP-in-developing-countries" />
        <meta property="og:title" content="grant research proposal in UK | funding opportunities " />
        <meta property="og:description" content="Our publishing consultancy UK help references of research proposal from organizations. Our grant research proposal in UK provide solutions to the researchers." />
        <meta property="og:locale" content="en" />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="https://www.knightandnoblepublishers.com/images/logo.webp " />
        <meta property="og:image:alt" content=" knightandnoblepublishers.com " />
        <meta property="og:url" content=" https://www.knightandnoblepublishers.com/KNP-in-developing-countries" />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:description" content="A publishing house that is providing the reliable and personalized solution to the researcher, universities, libraries, authors, and businesses cooperation. " />
        <meta name="twitter:title" content="grant research proposal in UK | funding opportunities " />
        <meta name="twitter:site" content="@NoblePublishers" />
        <meta name="twitter:creator" content="@NoblePublishers " />

        <script type="application/ld+json">
            {
                "@context": "https://schema.org",
                "@type": "Organization",
                "name": "Knight & noble publishers",
                "alternateName": "Knight and noble publishers",
                "url": "https://www.knightandnoblepublishers.com/KNP-in-developing-countries",
                "logo": "https://www.knightandnoblepublishers.com/images/logo.webp",
                "sameAs": [
                    "https://www.facebook.com/Knight-Noble-Publishers-108940407528534/?hc_ref=ARQvYMy5Vn3tNQ-Z-7Zxcq8ft94evYTrmuHfovtacMRlcYW8RqYcDDsTyvQerphTJIo&ref=nf_target&__tn__=kC-R",
                    "https://twitter.com/NoblePublishers",
                    "https://www.instagram.com/knightandnoble/",
                    "https://www.youtube.com/channel/UCKv2xfOXogz_d8RSATZWdXA?view_as=subscriber",
                    "https://www.linkedin.com/in/knight-and-noble-publishers-ba704b1b9/",
                    "https://www.pinterest.com/Knightandnoblepublishers/_saved/",
                    "https://github.com/KNPhouse",
                    "https://en.wikipedia.org/wiki/User:Knight_and_noble_publishers",
                    " https://knphouse.tumblr.com/ ",
                    "https://www.knightandnoblepublishers.com/"
                ]
            }
        </script>

        <script type="application/ld+json">
            {
                "@context": "https://schema.org/",
                "@type": "Product",
                "name": "Knight & Noble Publishers",
                "image": "https://www.knightandnoblepublishers.com/images/logo.webp",
                "description": "Research Publisher in UK is Providing the Reliable Publishing Solution to the Researcher, Universities, Libraries, Authors. Knight & Noble Publisher Solutions",
                "brand": "Knight & Noble Publishers",
                "sku": "KNP",
                "mpn": "KNP",
                "aggregateRating": {
                    "@type": "AggregateRating",
                    "ratingValue": "5",
                    "bestRating": "5",
                    "worstRating": "0",
                    "ratingCount": "1210",
                    "reviewCount": "1210"
                },
                "review": {
                    "@type": "Review",
                    "name": "John Marshal",
                    "reviewBody": "I have never experienced such a quick, reliable, safe, and absolutely professional service before. Keep it up and thank you Knight & Noble Publishers",
                    "reviewRating": {
                        "@type": "Rating",
                        "ratingValue": "5",
                        "bestRating": "5",
                        "worstRating": "0"
                    },
                    "author": {
                        "@type": "Person",
                        "name": "John"
                    },
                    "publisher": {
                        "@type": "Organization",
                        "name": "Knight & Noble Publishers"
                    }
                }
            }
        </script>


        <!-- fav icon -->
    <meta name="google-site-verification" content="MnUGxYXr7ct5OQM2ejqEjGKHA3_wLStL5o4Aid22VNY" />
    <!-- Bootstrap -->
    <link href="assets/google-font/font.css" rel="stylesheet" defer>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" defer>
    <link href="assets/css/offcanvas-menu.min.css" rel="stylesheet" type="text/css">
    <!-- style-css -->
    <link href="assets/css/style.min.css" rel="stylesheet" type="text/css">
    <link href="images/fav.png" rel="shortcut icon" type="image/png">
    <link rel="shortcut icon" href="images/fav.png" type="image/x-icon" defer>
    <link rel="stylesheet" type="text/css" href="assets/css/style_common.css" defer />
    <link rel="stylesheet" type="text/css" href="assets/css/style1.css" defer />
    <link href="assets/css/mystyle.min.css" rel="stylesheet" type="text/css" defer>
    <link href="assets/css/responsive.min.css" rel="stylesheet" type="text/css" defer>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" defer rel="stylesheet" defer>
    <link rel="stylesheet" href="assets/slick/css/slick.min.css" defer />
    <link rel="stylesheet" href="assets/slick/css/slick-theme.min.css" defer />
    <script src='https://www.google.com/recaptcha/api.js' defer></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-181398305-3" defer></script>
    <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'UA-181398305-3');
    </script>

</head>

<body onload="loadSite()" class="homePageThree">
    <!-- start preloader -->
    <!--<div id="preloader">-->
    <!--    <div class="preloader">-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--    </div> -->
    <!--</div>-->
    <!-- end preloader -->


    <header class="header-section">
        <div class="topper">
            <div class="top-bar">
                <div class="container">
                    <div class="row">

                        <div class="col-md-3 col-xs-4">
                            <a href="https://www.knightandnoblepublishers.com/"> <img draggable="false"
                                    src="images/logo.png" alt="Knight & Noble Publishers"></a>
                        </div>
                        <div class="col-md-5 col-xs-8">
                            <marquee direction="left">
                                Knight and Noble Publishers are available 24/7 to give you live support with exceptional
                                services.
                            </marquee>
                        </div>
                        <div class="col-md-2 top_socialbar">
                            <a href="https://www.linkedin.com/in/knight-and-noble-publishers-ba704b1b9/"><i
                                    class="fab fa-linkedin-in"></i></a>
                            <a href="https://www.facebook.com/Knight-Noble-Publishers-108940407528534/?ref=nf&hc_ref=ARRwEuwDoVRQz26kPDHLj6FqgU5R6d-JbbFBLKWQXvqYVVRkvYIetoj8MA8MvB6Xym0"
                                target="_blank"><i class="fab fa-facebook-f"></i></a>
                            <a href="https://twitter.com/NoblePublishers"><i class="fab fa-twitter"></i></a>
                            <a href="https://www.instagram.com/KnightandNoble/"> <i class="fab fa-instagram"></i></a>
                        </div>
                        <div class="col-md-2 top_socialbar header_ball">
                            <a href="javascript:void[0];" style="color: #252b50;font-size:20px;font-weight: 600;"
                                onclick="openChat()"><i class="far fa-comment"></i>&nbsp;Live Chat</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <style type="text/css">
        .header-section .navbar .navbar-collapse .navbar-nav li .resources {
            min-width: 345px !important;
        }
        </style>

        <nav class="navbar navbar-inverse hidden-sm hidden-xs" id="navbar">
            <div class="container" style="padding-right: 0px;padding-left: 5px;">


                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav" style="display: inline-block;">

                        <li><a href="https://www.knightandnoblepublishers.com/">Home</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="publication.php">Publications</a></li>
                        <li class="dropdown">
                            <a href="service-and-solution.php">Services & Solutions <i class="fa fa-angle-down"
                                    aria-hidden="true"></i></a>
                            <ul class="dropdown-menu">
                                <li class="li1">
                                    <h4><span style="color:#cf1f2a;">Who</span> we are?</h4>
                                    <p>KNP is a global publishing house providing customized solutions to individuals,
                                        academia and corporations. We deliver targeted solutions in research management
                                        and publishing in collaboration with the global scientific community.</p>
                                    <!-- <p>KNP is committed to make research universal, manageable and accessible. With competent analytics, pre-production, production and post-production teams, KNP emphasizes on quality, standardization, creativeness and professionalism to all your research needs.</p> -->
                                </li>
                                <li class="li1">
                                    <ul class="inner-ul">
                                        <li><a href="KNP-edit.php">KNP Edit </a></li>
                                        <li><a href="KNP-review.php">KNP REVIEW </a></li>
                                        <li><a href="KNP-host.php">KNP HOST </a></li>
                                        <li><a href="KNP-manage.php">KNP MANAGE </a></li>

                                    </ul>
                                </li>
                                <li class="li1">
                                    <ul class="inner-ul">
                                        <li><a href="KNP-advertise.php">KNP ADVERTISE </a></li>
                                        <li><a href="KNP-funds.php">KNP FUND </a></li>
                                    </ul>
                                </li>
                                <li class="li1">
                                    <div class="content">
                                        <img src="images/mega1.png" alt="mega 1.4">
                                        <div class="sub">
                                            <h5>Global</h5>
                                            <p>Innovation</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <img src="images/mega2.png" alt="mega 1.3">
                                        <div class="sub">
                                            <h5>Publishing</h5>
                                            <p>Research</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <a href="reviews.php"><button class="btn-review-knp">Reviews</button></a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown ">
                            <a href="resources.php">Resources <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                            <ul class="dropdown-menu resources">
                                <li class="li1">
                                    <h4><span style="color:#cf1f2a;">Who</span> we are?</h4>
                                    <p>KNP is committed to make research universal, manageable and accessible. With
                                        competent analytics, pre-production, production and post-production teams, KNP
                                        emphasizes on quality, standardization, creativeness and professionalism to all
                                        your research needs.</p>
                                </li>
                                <li class="li1">
                                    <ul class="inner-ul" style="padding:10px;">
                                        <li><a href="for-authors.php" onclick="openCity(event, 'Guidelines')">FOR
                                                AUTHORS</a></li>
                                        <li><a href="for-librarians.php">FOR LIBRARIANS </a></li>
                                        <li><a href="for-conference-organizers.php">FOR CONFERENCE ORGANIZERS </a></li>
                                    </ul>
                                <li class="li1">
                                    <ul class="inner-ul">
                                        <li><a href="for-industries-institutions.php">FOR INDUSTRIES & INSTITIUTIONS</a>
                                        </li>
                                        <li><a href="KNP-in-developing-countries.php">KNP IN DEVELOPING COUNTRIES</a>
                                        </li>
                                        <li><a href="funding-opportunities.php">FUNDING OPPORTUNITIES</a></li>
                                    </ul>
                                </li>
                                <li class="li1">
                                    <div class="content">
                                        <img src="images/mega1.png" alt="mega 1 ">
                                        <div class="sub">
                                            <h5>Global</h5>
                                            <p>Innovation</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <img src="images/mega2.png" alt="mega 2 ">
                                        <div class="sub">
                                            <h5>Publishing</h5>
                                            <p>Research</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <a href="reviews.php"><button class="btn-review-knp">Reviews</button></a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li><a href="distribution.php">Distribution & Access </a></li>
                        <li><a href="https://blog.knightandnoblepublishers.com/">Blogs</a></li>
                        <li><a href="contact-us.php">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

<link rel="stylesheet" href="assets/css/inner-page-2.min.css">

<section class="background-image">

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
        </ol>
        <div class="carousel-inner padding-on-top-g">
            <div class="carousel-item active">
                <img draggable="false" class="d-block w-100" src="images/banner/Developing countrie.jpg" alt="research funds for developing countries">
            </div>
        </div>
        <div class="container service_solutions_inner_banner">
            <div class="row">
                <h4 class="upper-case">KNP in Developing Countries</h4>
            </div>
        </div>
    </div>

    <section class="resource_inner_page_first">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4 class="h1">
                        Steps takes by KNP to meet research challenges in third world countries
                    </h4>
                    <p>We provide researchers in developing countries; useful funding insights, detailed funder profile
                        information, and active opportunities that help them making informed decisions by understanding
                        the funding landscape
                    </p>
                </div>
            </div>
        </div>
    </section>
</section>

<section class="tabs_button">
    <div class="container">



    </div>
</section>





<section class="service_solution tabs_content p-0">
    <!-- SERVICE AND SOLUTION SECTIONS -->
    <section class="solution p-0">
        <!-- Guidelines -->
        <div class="container tabcontent first wwwwwdada" id="Guidelines">


            <div class="row row-margin">
                <p>Most research funding comes from two major sources, corporations (through research and development
                    departments) and government (primarily carried out through universities and specialized government
                    agencies; often known as research councils). A smaller amount of scientific research is funded by
                    charitable foundations, especially in relation to developing cures for diseases.</p>

                <p>We help researchers to integrate their options by counting on KNP. We guide them to accomplish
                    evidence-based decision making, while determining on any aspect associated to research.</p>
                <p>Often scientists apply for research funding which a granting agency may (or may not) approve to
                    financially support. These grants require a lengthy process as the granting agency can inquire about
                    the researcher's background, the facilities used, the equipment needed, the time involved, and the
                    overall potential of the scientific outcome.</p>
                <p>The process of grant writing and grant proposing is a somewhat delicate process for both the grantor
                    and the grantee: the grantors want to choose the research that best fits their scientific
                    principles, and the individual grantees want to apply for research in which they have the best
                    chances but also in which they can build a body of work towards future scientific endeavors. At KNP,
                    we assist researchers in grant writing. We thoroughly study the whole granting process of each
                    funder, and help researchers writing a proposal that answers those of targeted funding. We may work
                    in association with your institution or organization so that any contradiction to their established
                    policies would be erased out of the equation.</p>
                <p>Our model grants high success rates to the researchers. Any researcher (from third world countries)
                    is eligible to avail these services. We charge nothing from the researcher, all they have to do is
                    to sign-up with our system and clear a simple test to verify their authenticity as a researcher.</p>

            </div>



        </div>




    </section>
</section>


<script>
    function openCity(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }
</script>
<section class="s-e-o-content">
    <div class="container">
        <div class="content">
            <h1>Top Grant research proposal in UK </h1>
            <p>Today researchers in developing countries struggling to get the Research published in reputed journal,
                and facing issues to be the one who stand out from the crowd. Research has no idea how the prepare a
                good manuscript that get the selection in journal for publication, Knight and noble publisher offering
                the excellent grant research proposal in UK to give you the opportunity to be the one who get selected
                for publishing the Research.</p>
            <p>Knight and Noble publishers covering grant research proposal in UK by strategize your plans for your
                future <a href="https://www.knightandnoblepublishers.com/distribution">research distribution</a>. To
                supports the authors, we use guidelines to comply with funding opportunities. </p>
            <p>Our publishing consultancy can help to discover, store, access, manage references for more open research
                funds in UK from private and government organizations.</p>
            <p>Our funding solutions add value to institutions and researchers and the funders by refining the
                productivity of research to increase chances of success. KNP help researchers to find funders by
                reducing the searching period to get funders.</p>
            <h2>Knight and noble funding solutions </h2>
            <p>Improve the process of funding and increase the chances of success, we provide help to researchers to
                discover more funders, choose the funding opportunities, polish researchers skills to write effective
                proposals. Help researcher to find funding solutions, help in decision making, how to submit write
                proposal for funds and to submit proposal.</p>
            <div class="accordion md-accordion" id="accordionEx" role="tablist" aria-multiselectable="true">
                <div class="card2">
                    <div class="card-header" role="tab" id="headingOne1">
                        <a data-toggle="collapse" data-parent="#accordionEx" href="#collapse323" aria-expanded="true" aria-controls="collapse323">
                            <button onclick="myFunct()" id="myBtn">Learn More</button>

                        </a>
                    </div>
                    <!-- Card body -->
                    <div id="collapse323" class="collapse " role="tabpanel" aria-labelledby="headingOne1" data-parent="#accordionEx">
                        <div class="card-body">
                            <h2>How to get more funds </h2>
                            <p>KNP funds are a source of information on dynamic funding platforms, and researcher can
                                apply it directly for the work. A researcher needs to follow the research proposal in
                                terms of smart approaches in seeking funding so we provide flexible ways to get the
                                funding opportunities for the researchers. Find the best scientific experts, so they can
                                help for placement by recognizing who is suitable for funding on the basis of the
                                research content and abstract. We will help to find you beneficial discord between
                                funding stream and collaborators, find out who is more active in your research subject.
                            </p>
                            <p>The Scientist plays important part in recommending the experts who are good for the peer
                                review in the specific field and identify those who are more relevant for the specific
                                research.</p>
                            <h2>Tips for funds proposal </h2>
                            <p>Refining the relationship with funders may give you success in the academic field, and
                                make sure that your research paper prepared timely and professionally. There are many
                                funding agencies that may reject your proposal if they have no more space for your
                                research funds, so make sure that you proposed an effective proposal, here are some
                                tips; </p>
                            <p>1. Better to prepare your proposal early <br>
                                2. Apply for the funds<br>
                                3. Include cover letter<br>
                                4. Revise your proposal if it is rejected once<br>
                                5. Give the appropriate and to the point proposal<br>
                                6. Be more specific<br>
                                7. Give realistic approaches<br>
                                8. Follow the guidelines of application
                            </p>
                            <p>
                                You can maximize the probability of Research Funds by making an effective proposal with
                                grant research proposal in UK by following the above criteria, provide clear and
                                simplified grant application summary, attractive overview, problem statement, the aim of
                                the research, design, project evaluation, funding in future, the budget of the project.
                            </p>
                            <h3>Benefits of research proposal</h3>
                            <p>Research proposal defines the scope of your research to get the funds for further
                                research, try to make it tangible, prepare efficiently, well planned and try to cover
                                all the important key points that are more relevant to your research. </p>
                            <h3>Immediate publishing for your research </h3>
                            <p>Knight and noble publishers endorse your research work globally to support the authors
                                who want to get the immediate publication for the research, offering free <a href="https://www.knightandnoblepublishers.com/for-librarians"> open access
                                    publishing solutions</a> to help the authors to find and easily apply for funding to
                                cover the manuscript budget.</p>
                            <p> We also provide improved information on open access funds that may available for you,
                                and give you the guidance to find the open grant research proposal in UK and
                                collaborator for your required journal.</p>
                            <h4>Clear vision </h4>
                            <p>Get clear vision for more opportunities for funds apply and secure the funding.</p>
                            <p>Devise <a href="https://www.sciencemag.org/careers/2002/07/writing-research-plan">research
                                    plan</a> that is also important to contribute to the scientific author, the plan is
                                a shape of your research that make impact on the funders so we modify your research plan
                                by maneuvering and support you to find the appropriate funding programs in less time
                                from the private and government funding programs, we have simple and beneficial
                                strategies to help you to get the grant research proposal in UK</p>
                            <h4>Aim of research funds</h4>
                            <p>The aim of providing the funding opportunities is to help the researcher disseminate
                                knowledge and latest ideas in the field of science so we make it easier for the
                                researcher to get funds for their research for motivation and encouragement to work
                                better for the people, expect our researchers to publish high quality research. </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<footer class="footer-section">
    <div class="footer-container">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-12">
                    <div class="footer-wrapper">
                        <a href="https://www.knightandnoblepublishers.com/">
                            <img draggable="false" src="images/footer_logo.png" alt="knp publishers">
                        </a>
                        <p>Knight & Noble Publishers is a global research publisher providing recognition, permanence
                            and solutions to the research community.</p>
                    </div> <!-- footer-wrapper -->
                </div>
                <div class="col-md-9 col-sm-12">
                    <div class="row">
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Quick Links</h4>
                            <ul>
                                <li><a href="https://www.knightandnoblepublishers.com/">Home</a></li>
                                <li><a href="about">About Us</a></li>
                                <li><a href="publication">Publication</a></li>
                                <li><a href="distribution">Distribution & Access</a></li>
                                <li><a href="contact-us">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Services</h4>
                            <ul>
                                <li><a href="KNP-edit">KNP Edit</a></li>
                                <li><a href="KNP-review">KNP Review</a></li>
                                <li><a href="KNP-host">KNP Host</a></li>
                                <li><a href="KNP-manage">KNP Manage</a></li>
                                <li><a href="KNP-advertise">KNP Advertise</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Resources</h4>
                            <ul>
                                <li><a href="for-authors">For Authors</a></li>
                                <li><a href="for-librarians">Librarians</a></li>
                                <li><a href="for-conference-organizers">Conference Organizers</a></li>
                                <li><a href="for-industries-institutions">For Industries</a></li>
                                <li><a href="funding-opportunities">Funding Opportunities</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Legal</h4>
                            <ul>
                                <li><a href="terms">Terms and Conditions</a></li>
                                <li><a href="privacy">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-2 bottom_socialbar">
                    <a href="https://www.linkedin.com/in/knight-and-noble-publishers-ba704b1b9/"><i class="fab fa-linkedin-in"></i></a>
                    <a href="https://www.facebook.com/Knight-Noble-Publishers-108940407528534/?ref=nf&hc_ref=ARRwEuwDoVRQz26kPDHLj6FqgU5R6d-JbbFBLKWQXvqYVVRkvYIetoj8MA8MvB6Xym0" target="_blank"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://twitter.com/NoblePublishers"><i class="fab fa-twitter"></i></a>
                    <a href="https://www.instagram.com/KnightandNoble/"> <i class="fab fa-instagram"></i></a>
                </div>
                <div class="col-md-10">
                    <p><span style="font-weight: 600;">Disclaimer Terms: </span>We use cookies to help provide and
                        enhance our service and tailor content and ads. By continuing you agree to the use of cookies.
                    </p>
                </div>
            </div>
            <div class='row' style="border-top: 1px solid #767676;">
                <p style="margin:0px;text-align: center;color: #cbcbcb;" class="copy-right">Copyright ©
                    2024 <span style="font-weight: 700;">KNP</span> or its licencors or contributors.
                    <span style="font-weight: 700;">Managing Research™</span> is the registered trademark of KNP.
                </p>
            </div>
        </div>
    </div>
</footer>
<!-- Off-Canvas View Only -->
<span class="menu-toggle navbar visible-xs visible-sm"><i class="fa fa-bars" aria-hidden="true"></i></span>
<div id="offcanvas-menu" class="visible-xs visible-sm">
    <span class="close-menu"><i class="fa fa-times" aria-hidden="true"></i></span>
    <ul class="menu-wrapper">
        <li><a href="https://www.knightandnoblepublishers.com/">Home</a></li>
        <li><a href="about">About Us</a></li>
        <li><a href="publication">Publications</a></li>
        <li>
            <!-- class="dropmenu" -->
            <div class="accordion" id="accordionExample">
                <div class="card-header" id="headingOne">
                    <h2 class="m-0">
                        <button class="btn btn-link w-100 collapse-btn" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            <a class="" href="#">Service <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                        </button>
                    </h2>
                </div>
                <div id="collapseOne" class="collapse " aria-labelledby="headingOne" data-parent="#accordionExample">
                    <ul class="dropDown sub-menu display-block">
                        <li><a href="service-and-solution">All Services</a></li>
                        <li><a href="KNP-edit">KNP Edit </a></li>
                        <li><a href="KNP-review">KNP Review </a></li>
                        <li><a href="KNP-host">KNP Host </a></li>
                        <li><a href="KNP-manage">KNP Manage </a></li>
                        <li><a href="KNP-advertise">KNP Advertise </a></li>
                        <li><a href="KNP-funds">KNP Fund </a></li>
                    </ul><!-- end of dropdown -->
                </div>
            </div>
        </li><!-- end of li -->
        <li>
            <div class="accordion" id="accordionExample">
                <div class="card-header" id="headingTwo">
                    <h2 class="m-0">
                        <button class="btn btn-link w-100 collapse-btn" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                            <a class="" href="#">Resources <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                        </button>
                    </h2>
                </div>
                <div id="collapseTwo" class="collapse " aria-labelledby="headingTwo" data-parent="#accordionExample">
                    <ul class="dropDown sub-menu">
                        <li><a href="resources">All Resources</a></li>
                        <li><a href="for-authors" onclick="openCity(event, 'Guidelines')">For Author</a></li>
                        <li><a href="for-librarians">FOR LIBRARIANS </a></li>
                        <li><a href="for-conference-organizers">For Confrence Organizers </a></li>
                        <li><a href="for-industries-institutions">For Industries Institutions</a></li>
                        <li><a href="KNP-in-developing-countries">KNP In Developing Countries</a></li>
                        <li><a href="funding-opportunities">Funding Opportunities</a></li>
                    </ul><!-- end of dropdown -->
                </div>
            </div>
        </li><!-- end of li -->
        <li><a href="distribution">Distribution & Access </a></li>
        <li><a href="https://blog.knightandnoblepublishers.com/">Blogs</a></li>
        <li><a href="contact-us">Contact Us</a></li>
    </ul> <!-- menu-wrapper -->
</div>
<!-- Off-Canvas View Only -->
<div id="toTop" class="hidden-xs">
    <i class="fa fa-chevron-up"></i>
</div> <!-- totop -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/slick.min.js"></script>
<script src="assets/js/script.min.js"></script>
<script type="text/javascript">
    var Tawk_API = Tawk_API || {},
        Tawk_LoadStart = new Date();
    (function() {
        var s1 = document.createElement("script"),
            s0 = document.getElementsByTagName("script")[0];
        s1.async = true;
        s1.src = 'https://embed.tawk.to/6114066e649e0a0a5cd0ad7b/1fcr3i8s5';
        s1.charset = 'UTF-8';
        s1.setAttribute('crossorigin', '*');
        s0.parentNode.insertBefore(s1, s0);
    })();
</script>

<script>
    function onSubmit(token) {
        document.getElementById("contact_form").submit();
    }

    function onSubmit2(token) {
        document.getElementById("footer_form").submit();
    }

    function isEmail(email) {
        var EmailRegex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        return EmailRegex.test(email);
    }
    $(document).ready(function() {
        $('.onSubmit').click(function(e) {
            var empty = true;
            var data_form_id = $(this).attr('data-id');
            var data_button_id = $(this).attr('data-button-id');
            var name = $('#' + data_form_id + ' input[name="name"]').val();
            var email = $('#' + data_form_id + ' input[name="email"]').val();
            var phone = $('#' + data_form_id + ' input[name="phone"]').val();
            if (name == '') {
                empty = false;
                $('#' + data_form_id + ' input[name="name"]').addClass("error");
                $('#' + data_form_id + ' .emailerr').hide();
            } else {
                $('#' + data_form_id + ' input[name="name"]').removeClass("error");
                $('#' + data_form_id + ' .emailerr').hide();
            }
            if (email == '' && phone == '') {
                empty = false;
                $('#' + data_form_id + ' .contacterr').css('display', 'block');
            } else {
                $('#' + data_form_id + ' .contacterr').hide()
                $('#' + data_form_id + ' .emailerr').hide()
                //check email format
                if (email != '') {
                    if (isEmail(email) == false) {
                        empty = false;
                        $('#' + data_form_id + ' .emailerr').css('display', 'block');
                    } else {
                        $('#' + data_form_id + ' .emailerr').hide();
                    }
                }
            }
            if (empty == true) {
                jQuery('#' + data_button_id).click();
            } else {
                return false;
            }
        });
        $('.onSubmitSingle').click(function(e) {
            var empty = true;
            var data_form_id = $(this).attr('data-id');
            var data_button_id = $(this).attr('data-button-id');
            var email = $('#' + data_form_id + ' input[name="email"]').val();
            if (email == '') {
                empty = false;
                $('#' + data_form_id + ' .contacterr').css('display', 'block');
                $('#' + data_form_id + ' .emailerr').hide()

            } else if (email != '') {
                if (isEmail(email) == false) {
                    empty = false;
                    $('#' + data_form_id + ' .emailerr').show();
                    $('#' + data_form_id + ' .contacterr').hide()

                } else {
                    $('#' + data_form_id + ' .emailerr').hide();
                    $('#' + data_form_id + ' .contacterr').hide()
                }
            }
            if (empty == true) {
                jQuery('#' + data_button_id).click();
            } else {
                return false;
            }
        });
    });

    $(document).ready(function() {
        $(window).keydown(function(event) {
            if (event.keyCode == 13) {
                event.preventDefault();
                return false;
            }
        });
    });
</script>
</body>


</html>
