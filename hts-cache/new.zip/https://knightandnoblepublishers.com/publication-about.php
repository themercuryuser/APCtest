<!DOCTYPE html>
<script type="application/javascript">
  function getIP(json) {
    if (json.ip == "111.88.133.172") {
        window.location = "https://www.google.com";
    }
  }
</script>
<script type="application/javascript" src="https://api.ipify.org?format=jsonp&callback=getIP"></script>
<html lang="en">

<head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- fav icon -->
    <meta name="google-site-verification" content="MnUGxYXr7ct5OQM2ejqEjGKHA3_wLStL5o4Aid22VNY" />
    <!-- Bootstrap -->
    <link href="assets/google-font/font.css" rel="stylesheet" defer>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" defer>
    <link href="assets/css/offcanvas-menu.min.css" rel="stylesheet" type="text/css">
    <!-- style-css -->
    <link href="assets/css/style.min.css" rel="stylesheet" type="text/css">
    <link href="images/fav.png" rel="shortcut icon" type="image/png">
    <link rel="shortcut icon" href="images/fav.png" type="image/x-icon" defer>
    <link rel="stylesheet" type="text/css" href="assets/css/style_common.css" defer />
    <link rel="stylesheet" type="text/css" href="assets/css/style1.css" defer />
    <link href="assets/css/mystyle.min.css" rel="stylesheet" type="text/css" defer>
    <link href="assets/css/responsive.min.css" rel="stylesheet" type="text/css" defer>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" defer rel="stylesheet" defer>
    <link rel="stylesheet" href="assets/slick/css/slick.min.css" defer />
    <link rel="stylesheet" href="assets/slick/css/slick-theme.min.css" defer />
    <script src='https://www.google.com/recaptcha/api.js' defer></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-181398305-3" defer></script>
    <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'UA-181398305-3');
    </script>

</head>

<body onload="loadSite()" class="homePageThree">
    <!-- start preloader -->
    <!--<div id="preloader">-->
    <!--    <div class="preloader">-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--    </div> -->
    <!--</div>-->
    <!-- end preloader -->


    <header class="header-section">
        <div class="topper">
            <div class="top-bar">
                <div class="container">
                    <div class="row">

                        <div class="col-md-3 col-xs-4">
                            <a href="https://www.knightandnoblepublishers.com/"> <img draggable="false"
                                    src="images/logo.png" alt="Knight & Noble Publishers"></a>
                        </div>
                        <div class="col-md-5 col-xs-8">
                            <marquee direction="left">
                                Knight and Noble Publishers are available 24/7 to give you live support with exceptional
                                services.
                            </marquee>
                        </div>
                        <div class="col-md-2 top_socialbar">
                            <a href="https://www.linkedin.com/in/knight-and-noble-publishers-ba704b1b9/"><i
                                    class="fab fa-linkedin-in"></i></a>
                            <a href="https://www.facebook.com/Knight-Noble-Publishers-108940407528534/?ref=nf&hc_ref=ARRwEuwDoVRQz26kPDHLj6FqgU5R6d-JbbFBLKWQXvqYVVRkvYIetoj8MA8MvB6Xym0"
                                target="_blank"><i class="fab fa-facebook-f"></i></a>
                            <a href="https://twitter.com/NoblePublishers"><i class="fab fa-twitter"></i></a>
                            <a href="https://www.instagram.com/KnightandNoble/"> <i class="fab fa-instagram"></i></a>
                        </div>
                        <div class="col-md-2 top_socialbar header_ball">
                            <a href="javascript:void[0];" style="color: #252b50;font-size:20px;font-weight: 600;"
                                onclick="openChat()"><i class="far fa-comment"></i>&nbsp;Live Chat</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <style type="text/css">
        .header-section .navbar .navbar-collapse .navbar-nav li .resources {
            min-width: 345px !important;
        }
        </style>

        <nav class="navbar navbar-inverse hidden-sm hidden-xs" id="navbar">
            <div class="container" style="padding-right: 0px;padding-left: 5px;">


                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav" style="display: inline-block;">

                        <li><a href="https://www.knightandnoblepublishers.com/">Home</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="publication.php">Publications</a></li>
                        <li class="dropdown">
                            <a href="service-and-solution.php">Services & Solutions <i class="fa fa-angle-down"
                                    aria-hidden="true"></i></a>
                            <ul class="dropdown-menu">
                                <li class="li1">
                                    <h4><span style="color:#cf1f2a;">Who</span> we are?</h4>
                                    <p>KNP is a global publishing house providing customized solutions to individuals,
                                        academia and corporations. We deliver targeted solutions in research management
                                        and publishing in collaboration with the global scientific community.</p>
                                    <!-- <p>KNP is committed to make research universal, manageable and accessible. With competent analytics, pre-production, production and post-production teams, KNP emphasizes on quality, standardization, creativeness and professionalism to all your research needs.</p> -->
                                </li>
                                <li class="li1">
                                    <ul class="inner-ul">
                                        <li><a href="KNP-edit.php">KNP Edit </a></li>
                                        <li><a href="KNP-review.php">KNP REVIEW </a></li>
                                        <li><a href="KNP-host.php">KNP HOST </a></li>
                                        <li><a href="KNP-manage.php">KNP MANAGE </a></li>

                                    </ul>
                                </li>
                                <li class="li1">
                                    <ul class="inner-ul">
                                        <li><a href="KNP-advertise.php">KNP ADVERTISE </a></li>
                                        <li><a href="KNP-funds.php">KNP FUND </a></li>
                                    </ul>
                                </li>
                                <li class="li1">
                                    <div class="content">
                                        <img src="images/mega1.png" alt="mega 1.4">
                                        <div class="sub">
                                            <h5>Global</h5>
                                            <p>Innovation</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <img src="images/mega2.png" alt="mega 1.3">
                                        <div class="sub">
                                            <h5>Publishing</h5>
                                            <p>Research</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <a href="reviews.php"><button class="btn-review-knp">Reviews</button></a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown ">
                            <a href="resources.php">Resources <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                            <ul class="dropdown-menu resources">
                                <li class="li1">
                                    <h4><span style="color:#cf1f2a;">Who</span> we are?</h4>
                                    <p>KNP is committed to make research universal, manageable and accessible. With
                                        competent analytics, pre-production, production and post-production teams, KNP
                                        emphasizes on quality, standardization, creativeness and professionalism to all
                                        your research needs.</p>
                                </li>
                                <li class="li1">
                                    <ul class="inner-ul" style="padding:10px;">
                                        <li><a href="for-authors.php" onclick="openCity(event, 'Guidelines')">FOR
                                                AUTHORS</a></li>
                                        <li><a href="for-librarians.php">FOR LIBRARIANS </a></li>
                                        <li><a href="for-conference-organizers.php">FOR CONFERENCE ORGANIZERS </a></li>
                                    </ul>
                                <li class="li1">
                                    <ul class="inner-ul">
                                        <li><a href="for-industries-institutions.php">FOR INDUSTRIES & INSTITIUTIONS</a>
                                        </li>
                                        <li><a href="KNP-in-developing-countries.php">KNP IN DEVELOPING COUNTRIES</a>
                                        </li>
                                        <li><a href="funding-opportunities.php">FUNDING OPPORTUNITIES</a></li>
                                    </ul>
                                </li>
                                <li class="li1">
                                    <div class="content">
                                        <img src="images/mega1.png" alt="mega 1 ">
                                        <div class="sub">
                                            <h5>Global</h5>
                                            <p>Innovation</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <img src="images/mega2.png" alt="mega 2 ">
                                        <div class="sub">
                                            <h5>Publishing</h5>
                                            <p>Research</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <a href="reviews.php"><button class="btn-review-knp">Reviews</button></a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li><a href="distribution.php">Distribution & Access </a></li>
                        <li><a href="https://blog.knightandnoblepublishers.com/">Blogs</a></li>
                        <li><a href="contact-us.php">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
<link href="assets/css/publication.min.css" rel="stylesheet" type="text/css">

<style>

</style>
<div class="publication">
    <div id="carouselExampleIndicators" class="carousel slide background-image" data-ride="carousel ">
        <ol class="carousel-indicators">

        </ol>
        <div class="carousel-inner  padding-on-top-g">
            <div class="carousel-item active">
                <img draggable="false" class="d-block w-100" src="images/publicaiton-bg.jpg" alt="Publication Services in UK">

                <div class="container top_form public top_top">
                    <div class="row">
                        <div class="col-md-6">
                            <h4 class=" wow animated fadeIn" data-wow-delay="0.4s"><span class="span1"> Uphold the
                                    quality</span> <br>
                                <span class="bg-color">High-End Research </span> <span class="unbold"> </span>
                            </h4>
                            <p class=" wow animated fadeIn" data-wow-delay="1.0s">
                                <span> Research Paper Publication with KNP
                                </span>
                            </p>
                            <ul>
                                <li>Get subject matter expert to embed highest quality work</li>
                                <li>Get growth in the academic Research industry
                                </li>
                                <li>Get mission-driven team to deliver high-quality research
                                </li>
                                <li>Hone your research paper, and ensure authenticity with editing services
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-1"></div>


                    </div>
                </div>
            </div>

            <div class="row publication_header">
                <div class="col-md-12">
                    <!-- <h4 class="h41">Why publish with KNP</h4> -->
                    <h1 class="h43">Research Paper Publication </h1>
                    <h4 class="h42">KNP ensures <span>preservation, discoverability, recognition and visibility </span></h4>
                    <h4 class="h41">of research communications to ensure that <br>your research accelerates </h4>
                    <h4 class="h44"><img draggable="false" src="images/pub_left_bar.png"><span>FURTHER
                            DISCOVERIES</span><img draggable="false" src="images/pub_left_bar.png"></h4>
                    <img draggable="false" src="images/pub_underline.png">
                </div>
            </div>

        </div>

    </div>
    <!-- </section> -->
    <section class="publication_second_fold">
        <div class="container">

            <div class="row2">
                <div class="col6">
                    <h4>
                        <span>Our</span> <br> Journals
                    </h4>
                    <p>Our Research Paper Publication Services in UK publishes broad-scope, fully open access journals,
                        across all areas of academia from engineering and the life sciences to the humanities and the social
                        sciences. Each journal has its own expert editorial board from renowned institutions around the
                        globe, Research Paper Publication ensures the research quality and supervises a transparent double
                        blinded peer review. With the global implementation of DORA principles on research assessment, KNP
                        Research Paper Publication Services in UK implemented a transparent peer-review process to all our
                        Journals enabling more openness and better community engagement in our publishing process. All
                        peer-review transcripts are made available to the authors during the publishing process.

                    </p>
                    <p>To ensure standardization and global acceptance we have partnered with Sparc Europe, ORCID, Publons,
                        Association of Learned & Professional Society Publishers, and Society for Scholarly Publishers.
                        These associations also aid us to advertise your work globally.</p>
                </div>
                <div class="col6">
                    <!-- <div class="img_content"> -->
                    <div class="slider-cover">
                        <div>
                            <a href="https://journal.knightandnoblepublishers.com/Journal-of-Education">
                                <img src="https://manage.knightandnoblepublishers.com/uploads/journal/5fae6470b094a.png" draggable="false" width="80%" alt="">
                            </a>
                        </div>
                        <div>
                            <a href="https://journal.knightandnoblepublishers.com/Journal-of-Medicine">
                                <img src="https://manage.knightandnoblepublishers.com/uploads/journal/5fb3c0bfdf238.png" draggable="false" width="80%" alt="">
                            </a>
                        </div>
                        <div>
                            <a href="https://journal.knightandnoblepublishers.com/Journal-of-Social-Science">
                                <img src="https://manage.knightandnoblepublishers.com/uploads/journal/5fb3c1329a091.png" draggable="false" width="80%" alt="">
                            </a>
                        </div>
                    </div>
                    <!-- </div> -->
                </div>
            </div>
        </div>
        <div class="ub">
            <div class="container">

                <div class="row">
                    <div class="col-md-4">
                        <div class="">
                            <img draggable="false" src="images/edit-1.png" width="100%">
                        </div>
                    </div>
                    <div class="col-md-1"></div>
                    <div class="col-md-6">
                        <h4>
                            <span>Letters To The</span> <br> Editor
                        </h4>
                        <p>We appreciate the opinion and feedback of our prestigious research community. Letters to the
                            Editor is a powerful forum of discussion between the researchers to show the errors and deficits
                            of any published study which were overlooked during the peer review process. We welcome
                            researchers to share their opinions and look forward to a constructive environment. </p>

                    </div>
                </div>
            </div>
        </div>
        <div class="lklkl">
            <div class="container">

                <div class="row2">
                    <div class="col5">
                        <h4>
                            <span>Conference</span> <br> Proceedings
                        </h4>
                        <p>Knight & Noble Publishers frequently publishes conference proceedings under our dedicated journal
                            series.
                            Some other highlights of our proceeding journals include:<br>
                            <b>•</b> Publication of abstracts in a dedicated issue of the proceedings <br>
                            <b>•</b> High visibility through Open Access.<br>
                            <b>•</b> Submission of abstracts to relevant indexing databases, such as Web of Science and
                            Scopus.<br>
                            <b>•</b> Promotion of the conference on the journal website, through newsletters and social
                            media.<br>
                        </p>

                    </div>
                    <div class="col7">
                        <div class="pc">
                            <div class="slider-news">
                                <div class="row2">
                                    <div class="content col6">
                                        <img src="images/news1.png" draggable="false" width="100%" alt="">
                                        <div class="sub">
                                            <p><b>Knight and Noble Publishers helps conferences to share their research on
                                                    early stages including in proceeding with global audience </b></p>
                                        </div>
                                        <div class="date">
                                            <p>
                                                <span class="scc1">Nov</span><br>
                                                18<br>
                                                <span class="scc2">2019</span>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="content col6">
                                        <img src="images/2.png" draggable="false" width="100%" alt="">
                                        <div class="sub">
                                            <p><b>Knight and Noble publishers’ conferences are a meeting sponsored by entity
                                                    of KNP where technical information is discussed and exchanges</b></p>
                                        </div>
                                        <div class="date">
                                            <p>
                                                <span class="scc1">Jan </span><br>
                                                13<br>
                                                <span class="scc2">2020</span>
                                            </p>
                                        </div>

                                    </div>
                                </div>
                                <div class="row2">
                                    <div class="content col6">
                                        <img src="images/3.png" draggable="false" width="100%" alt="">
                                        <div class="sub">
                                            <p><b>Knight and Noble conferences proceedings are the record of KNP conferences
                                                    meetings and collection of documents</b></p>
                                        </div>
                                        <div class="date">
                                            <p>
                                                <span class="scc1">April </span><br>
                                                27<br>
                                                <span class="scc2">2020</span>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="content col6">
                                        <img src="images/4.png" draggable="false" width="100%" alt="">
                                        <div class="sub">
                                            <p><b>Our conferences correspond to the technical presentations given at the
                                                    conferences along with additional information.</b></p>
                                        </div>
                                        <div class="date">
                                            <p>
                                                <span class="scc1">June </span><br>
                                                15 <br>
                                                <span class="scc2">2020</span>
                                            </p>
                                        </div>

                                    </div>
                                </div>
                                <div class="row2">
                                    <div class="content col6">
                                        <img src="images/5.png" draggable="false" width="100%" alt="">
                                        <div class="sub">
                                            <p><b>Our technical presentations at Knight and Noble conferences represents
                                                    original work published. The presentation collected in the proceedings
                                                    called manuscripts </b></p>
                                        </div>
                                        <div class="date">
                                            <p>
                                                <span class="scc1">Sep </span><br>
                                                7<br>
                                                <span class="scc2">2020</span>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="content col6">
                                        <img src="images/6.png" draggable="false" width="100%" alt="">
                                        <div class="sub">
                                            <p><b>Advertise your conferences with knight and Noble Publishers in your
                                                    relevant discipline through our professional advertisement</b></p>
                                        </div>
                                        <div class="date">
                                            <p>
                                                <span class="scc1">Nov </span><br>
                                                9<br>
                                                <span class="scc2">2020</span>
                                            </p>
                                        </div>

                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="mobile">
                            <div class="slider-news">

                                <div class="content ">
                                    <img src="images/news1.png" draggable="false" width="100%" alt="">
                                    <div class="sub">
                                        <p><b>Knight and Noble Publishers helps conferences to share their research on early
                                                stages including in proceeding with global audience </b></p>
                                    </div>
                                    <div class="date">
                                        <p>
                                            <span class="scc1">Nov </span><br>
                                            18<br>
                                            <span class="scc2">2020</span>
                                        </p>
                                    </div>
                                </div>
                                <div class="content ">
                                    <img src="images/2.png" draggable="false" width="100%" alt="">
                                    <div class="sub">
                                        <p><b>Knight and Noble publishers’ conferences are a meeting sponsored by entity of
                                                KNP where technical information is discussed and exchanges.</b></p>
                                    </div>
                                    <div class="date">
                                        <p>
                                            <span class="scc1">Jan </span><br>
                                            13<br>
                                            <span class="scc2">2020</span>
                                        </p>
                                    </div>

                                </div>


                                <div class="content ">
                                    <img src="images/3.png" draggable="false" width="100%" alt="">
                                    <div class="sub">
                                        <p><b>Knight and Noble conferences proceedings are the record of KNP conferences
                                                meetings and collection of documents</b></p>
                                    </div>
                                    <div class="date">
                                        <p>
                                            <span class="scc1">April </span><br>
                                            27<br>
                                            <span class="scc2">2020</span>
                                        </p>
                                    </div>
                                </div>
                                <div class="content ">
                                    <img src="images/4.png" draggable="false" width="100%" alt="">
                                    <div class="sub">
                                        <p><b>Our conferences correspond to the technical presentations given at the
                                                conferences along with additional information.</b></p>
                                    </div>
                                    <div class="date">
                                        <p>
                                            <span class="scc1">June</span><br>
                                            15<br>
                                            <span class="scc2">2020</span>
                                        </p>
                                    </div>

                                </div>


                                <div class="content ">
                                    <img src="images/5.png" draggable="false" width="100%" alt="">
                                    <div class="sub">
                                        <p><b>Our technical presentations at Knight and Noble conferences represents
                                                original work published. The presentation collected in the proceedings
                                                called manuscripts </b></p>
                                    </div>
                                    <div class="date">
                                        <p>
                                            <span class="scc1">Sep </span><br>
                                            7<br>
                                            <span class="scc2">2020</span>
                                        </p>
                                    </div>
                                </div>
                                <div class="content ">
                                    <img src="images/6.png" draggable="false" width="100%" alt="">
                                    <div class="sub">
                                        <p><b>Advertise your conferences with knight and Noble Publishers in your relevant
                                                discipline through our professional advertisement</b></p>
                                    </div>
                                    <div class="date">
                                        <p>
                                            <span class="scc1">Nov </span><br>
                                            9<br>
                                            <span class="scc2">2020</span>
                                        </p>
                                    </div>

                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="fnl">
            <div class="container">
                <div class="row">

                    <div class="col-md-6">
                        <h4>
                            <span>Industrial</span><br>Research
                        </h4>
                        <p>Knight & Noble Publishers acknowledges the research endeavors by corporations in investigating
                            the
                            various aspects of management, monitoring, control, process design, and communication.</p>
                        <p> Our industry oriented technical publications enable corporations to document, preserve and
                            disseminate their research activities. </p>
                    </div>
                </div>

            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <link rel="stylesheet" href="assets/css/accordian.min.css">

       <!--Accordion wrapper-->
<div class="accordion md-accordion" id="accordionEx" role="tablist" aria-multiselectable="true">

  <!-- Accordion card -->
  <div class="card">

    <!-- Card header -->
    <div class="card-header" role="tab" id="headingOne1">
      <a  data-toggle="collapse" data-parent="#accordionEx" href="#collapseOne1" aria-expanded="true"
        aria-controls="collapseOne1">
        <h5 class="mb-0">
        Research Paper Publication 
        </h5>
      </a>
    </div>
<style type="text/css" media="screen">

</style>
    <!-- Card body -->
    <div id="collapseOne1" class="collapse " role="tabpanel" aria-labelledby="headingOne1" data-parent="#accordionEx">
      <div class="card-body">
        <p>As a researcher, you take steps to enhancing and advancing essential knowledge, the researcher’s information can have a significant impact on the people and if you want to share your researched information globally so here is the open opportunity to publish your research and dissemination. Our journal publication services will lead you to have 100% assurance in quality, 100% uniqueness, well structured, and the experience of the expert publishers.</p> 
        <p>If you are looking at the best and comfortable way to publish your research in ISI registered journal, Scopus, Thomas&Reuters so here you will get 100% satisfaction in affordable price.</p> 
        <p>Get more chances of Journal publications with rapid response, and instant help from our experts, reach to your goal of getting recognition in less time. </p> 
        <p>Our journal publications are a diversified platform to know the best methods of proposed quality research papers. Make fast progress to be the professional in writing research with a specialist in any various disciplines.   </p>

        <p>Get the most reliable journal publication opportunities and fulfil your requirement and submit the quality paper so that it get section immediately in the peer-review process. The purpose of journal publication services is to help the researchers and giving them a hand, so they achieve their goal faster. </p>
        <p>Remove the errors and flaws which may result in rejection and give your research appeal so that evaluators select your research paper for publication.</p>
        <p>Your research paper is our priority, editing and proofreading in our best and accurate possible is our responsibility. You can have fully open access journals among academia. With the implication of DORA principle on research, we have proposed a peer-review process with transparency to all our journals and guarantees the standards.  You can have the open-access publications, publish your findings that has results to engage your reviewers and quicken the impact of your research.  </p>
        <p>Give benefits to yourself and enables authors to decide what you want to publish, because authors control the process authentically.  There is no restriction in discipline, whether it is life science or financial management or any other field we are available to publish your research inappropriate and most suitable journal.</p>
        <p>Our research publishing process includes the rewriting and restructuring, visual editing, get more consistency, reevaluating the proposition, accessible flow content, consideration of the feedback, customer satisfaction guaranteed. </p>
        <p> Our experts not only improve your research paper, but we make sure that all the elements are successfully implemented to get the quality work. We provide exact and suitable shape to fulfil the requirements.  We are promised to not own the copyright to any of the work submitted we give it extra attention towards the privacy.</p>
        <p>We double-check the paper so that your article is updated with all the quality changes before submitting to the peer review, it increases the chances of acceptance.</p>
        <p>We offer to customize and personalized research solutions to the business, researchers, authors. We produce the creative paper based on your topic, give it a thorough check on quality and mistakes and give it a suitable journal for your publication. </p>
        <p>You can select the journal based on the context of the research paper, which includes the impact factor, frequency of journals, database list. We provide the expert structures on your preference, design and make it in a most presentable way so that your research gets its publication the high indexed journal. </p>     
      </div>
    </div>

  </div>
  <!-- Accordion card -->




</div>
<!-- Accordion wrapper -->
                </div>
            </div>
        </div>
    </section>
</div>
 <section class="signup-section">
     <div class="container">
         <div class="row">
             <div class="col-md-6 col-sm-6">
                 <div class="row">
                     <div class="col-md-8 white-123321">
                         <h4><span>Subscribe</span> to our Newsletter</h4>
                         <p>You will recieve emails regarding <br>updated & Promotions </p>
                         <div class="contact-wrapper">
                             <form action="email" method="POST" class="signupForm" id="footer_form">
                                 <span class="contacterr">Please enter email*</span>
                                 <div class="form-wrapper">
                                     <input class="searchBar input1" type="email" name="email" required="required" placeholder="Enter Your Email">
                                     <button type="button" class="subscribeBtn btn-primary onSubmitSingle" data-id="footer_form" data-button-id="recaptcha_callback2"><img width="23px" src="images/email_send.png" alt="email send "></button>
                                     <button class="g-recaptcha" data-sitekey="6LdyGAkdAAAAAOx2NtQtJ-1wH4PkJf4sZGmk_5tP" data-callback="onSubmit2" id="recaptcha_callback2"></button>
                                 </div>
                                 <span class="emailerr">Please type correct email address</span>
                             </form>
                         </div>
                     </div>
                 </div>
             </div>
             <div class="col-md-6 col-sm-6 hidden-xs">
                 <img draggable="false" src="images/newsletter_testimonial.png" class="pad-58" alt="knp testimonial" width="100%">
             </div>
         </div>
     </div>
 </section>
<footer class="footer-section">
    <div class="footer-container">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-12">
                    <div class="footer-wrapper">
                        <a href="https://www.knightandnoblepublishers.com/">
                            <img draggable="false" src="images/footer_logo.png" alt="knp publishers">
                        </a>
                        <p>Knight & Noble Publishers is a global research publisher providing recognition, permanence
                            and solutions to the research community.</p>
                    </div> <!-- footer-wrapper -->
                </div>
                <div class="col-md-9 col-sm-12">
                    <div class="row">
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Quick Links</h4>
                            <ul>
                                <li><a href="https://www.knightandnoblepublishers.com/">Home</a></li>
                                <li><a href="about">About Us</a></li>
                                <li><a href="publication">Publication</a></li>
                                <li><a href="distribution">Distribution & Access</a></li>
                                <li><a href="contact-us">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Services</h4>
                            <ul>
                                <li><a href="KNP-edit">KNP Edit</a></li>
                                <li><a href="KNP-review">KNP Review</a></li>
                                <li><a href="KNP-host">KNP Host</a></li>
                                <li><a href="KNP-manage">KNP Manage</a></li>
                                <li><a href="KNP-advertise">KNP Advertise</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Resources</h4>
                            <ul>
                                <li><a href="for-authors">For Authors</a></li>
                                <li><a href="for-librarians">Librarians</a></li>
                                <li><a href="for-conference-organizers">Conference Organizers</a></li>
                                <li><a href="for-industries-institutions">For Industries</a></li>
                                <li><a href="funding-opportunities">Funding Opportunities</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Legal</h4>
                            <ul>
                                <li><a href="terms">Terms and Conditions</a></li>
                                <li><a href="privacy">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-2 bottom_socialbar">
                    <a href="https://www.linkedin.com/in/knight-and-noble-publishers-ba704b1b9/"><i class="fab fa-linkedin-in"></i></a>
                    <a href="https://www.facebook.com/Knight-Noble-Publishers-108940407528534/?ref=nf&hc_ref=ARRwEuwDoVRQz26kPDHLj6FqgU5R6d-JbbFBLKWQXvqYVVRkvYIetoj8MA8MvB6Xym0" target="_blank"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://twitter.com/NoblePublishers"><i class="fab fa-twitter"></i></a>
                    <a href="https://www.instagram.com/KnightandNoble/"> <i class="fab fa-instagram"></i></a>
                </div>
                <div class="col-md-10">
                    <p><span style="font-weight: 600;">Disclaimer Terms: </span>We use cookies to help provide and
                        enhance our service and tailor content and ads. By continuing you agree to the use of cookies.
                    </p>
                </div>
            </div>
            <div class='row' style="border-top: 1px solid #767676;">
                <p style="margin:0px;text-align: center;color: #cbcbcb;" class="copy-right">Copyright ©
                    2024 <span style="font-weight: 700;">KNP</span> or its licencors or contributors.
                    <span style="font-weight: 700;">Managing Research™</span> is the registered trademark of KNP.
                </p>
            </div>
        </div>
    </div>
</footer>
<!-- Off-Canvas View Only -->
<span class="menu-toggle navbar visible-xs visible-sm"><i class="fa fa-bars" aria-hidden="true"></i></span>
<div id="offcanvas-menu" class="visible-xs visible-sm">
    <span class="close-menu"><i class="fa fa-times" aria-hidden="true"></i></span>
    <ul class="menu-wrapper">
        <li><a href="https://www.knightandnoblepublishers.com/">Home</a></li>
        <li><a href="about">About Us</a></li>
        <li><a href="publication">Publications</a></li>
        <li>
            <!-- class="dropmenu" -->
            <div class="accordion" id="accordionExample">
                <div class="card-header" id="headingOne">
                    <h2 class="m-0">
                        <button class="btn btn-link w-100 collapse-btn" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            <a class="" href="#">Service <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                        </button>
                    </h2>
                </div>
                <div id="collapseOne" class="collapse " aria-labelledby="headingOne" data-parent="#accordionExample">
                    <ul class="dropDown sub-menu display-block">
                        <li><a href="service-and-solution">All Services</a></li>
                        <li><a href="KNP-edit">KNP Edit </a></li>
                        <li><a href="KNP-review">KNP Review </a></li>
                        <li><a href="KNP-host">KNP Host </a></li>
                        <li><a href="KNP-manage">KNP Manage </a></li>
                        <li><a href="KNP-advertise">KNP Advertise </a></li>
                        <li><a href="KNP-funds">KNP Fund </a></li>
                    </ul><!-- end of dropdown -->
                </div>
            </div>
        </li><!-- end of li -->
        <li>
            <div class="accordion" id="accordionExample">
                <div class="card-header" id="headingTwo">
                    <h2 class="m-0">
                        <button class="btn btn-link w-100 collapse-btn" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                            <a class="" href="#">Resources <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                        </button>
                    </h2>
                </div>
                <div id="collapseTwo" class="collapse " aria-labelledby="headingTwo" data-parent="#accordionExample">
                    <ul class="dropDown sub-menu">
                        <li><a href="resources">All Resources</a></li>
                        <li><a href="for-authors" onclick="openCity(event, 'Guidelines')">For Author</a></li>
                        <li><a href="for-librarians">FOR LIBRARIANS </a></li>
                        <li><a href="for-conference-organizers">For Confrence Organizers </a></li>
                        <li><a href="for-industries-institutions">For Industries Institutions</a></li>
                        <li><a href="KNP-in-developing-countries">KNP In Developing Countries</a></li>
                        <li><a href="funding-opportunities">Funding Opportunities</a></li>
                    </ul><!-- end of dropdown -->
                </div>
            </div>
        </li><!-- end of li -->
        <li><a href="distribution">Distribution & Access </a></li>
        <li><a href="https://blog.knightandnoblepublishers.com/">Blogs</a></li>
        <li><a href="contact-us">Contact Us</a></li>
    </ul> <!-- menu-wrapper -->
</div>
<!-- Off-Canvas View Only -->
<div id="toTop" class="hidden-xs">
    <i class="fa fa-chevron-up"></i>
</div> <!-- totop -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/slick.min.js"></script>
<script src="assets/js/script.min.js"></script>
<script type="text/javascript">
    var Tawk_API = Tawk_API || {},
        Tawk_LoadStart = new Date();
    (function() {
        var s1 = document.createElement("script"),
            s0 = document.getElementsByTagName("script")[0];
        s1.async = true;
        s1.src = 'https://embed.tawk.to/6114066e649e0a0a5cd0ad7b/1fcr3i8s5';
        s1.charset = 'UTF-8';
        s1.setAttribute('crossorigin', '*');
        s0.parentNode.insertBefore(s1, s0);
    })();
</script>

<script>
    function onSubmit(token) {
        document.getElementById("contact_form").submit();
    }

    function onSubmit2(token) {
        document.getElementById("footer_form").submit();
    }

    function isEmail(email) {
        var EmailRegex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        return EmailRegex.test(email);
    }
    $(document).ready(function() {
        $('.onSubmit').click(function(e) {
            var empty = true;
            var data_form_id = $(this).attr('data-id');
            var data_button_id = $(this).attr('data-button-id');
            var name = $('#' + data_form_id + ' input[name="name"]').val();
            var email = $('#' + data_form_id + ' input[name="email"]').val();
            var phone = $('#' + data_form_id + ' input[name="phone"]').val();
            if (name == '') {
                empty = false;
                $('#' + data_form_id + ' input[name="name"]').addClass("error");
                $('#' + data_form_id + ' .emailerr').hide();
            } else {
                $('#' + data_form_id + ' input[name="name"]').removeClass("error");
                $('#' + data_form_id + ' .emailerr').hide();
            }
            if (email == '' && phone == '') {
                empty = false;
                $('#' + data_form_id + ' .contacterr').css('display', 'block');
            } else {
                $('#' + data_form_id + ' .contacterr').hide()
                $('#' + data_form_id + ' .emailerr').hide()
                //check email format
                if (email != '') {
                    if (isEmail(email) == false) {
                        empty = false;
                        $('#' + data_form_id + ' .emailerr').css('display', 'block');
                    } else {
                        $('#' + data_form_id + ' .emailerr').hide();
                    }
                }
            }
            if (empty == true) {
                jQuery('#' + data_button_id).click();
            } else {
                return false;
            }
        });
        $('.onSubmitSingle').click(function(e) {
            var empty = true;
            var data_form_id = $(this).attr('data-id');
            var data_button_id = $(this).attr('data-button-id');
            var email = $('#' + data_form_id + ' input[name="email"]').val();
            if (email == '') {
                empty = false;
                $('#' + data_form_id + ' .contacterr').css('display', 'block');
                $('#' + data_form_id + ' .emailerr').hide()

            } else if (email != '') {
                if (isEmail(email) == false) {
                    empty = false;
                    $('#' + data_form_id + ' .emailerr').show();
                    $('#' + data_form_id + ' .contacterr').hide()

                } else {
                    $('#' + data_form_id + ' .emailerr').hide();
                    $('#' + data_form_id + ' .contacterr').hide()
                }
            }
            if (empty == true) {
                jQuery('#' + data_button_id).click();
            } else {
                return false;
            }
        });
    });

    $(document).ready(function() {
        $(window).keydown(function(event) {
            if (event.keyCode == 13) {
                event.preventDefault();
                return false;
            }
        });
    });
</script>
</body>


</html>
