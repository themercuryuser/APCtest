<!DOCTYPE html>
<script type="application/javascript">
  function getIP(json) {
    if (json.ip == "111.88.133.172") {
        window.location = "https://www.google.com";
    }
  }
</script>
<script type="application/javascript" src="https://api.ipify.org?format=jsonp&callback=getIP"></script>
<html lang="en">

<head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> Open Access Publication Funds | Funding for Research in UK </title>
    <meta name="title" content=" Open Access Publication Funds | Funding for Research in UK " />
    <meta name="description" content="Knight and Noble Publishers help researchers to Open Access publication Funds. We provide
    free Open Access Publication Funds support service to the researchers. ">
    <meta name="keywords" content="Open Access Publication Funds, Funding for Research in UK ">
    <meta name="robots" content="index, follow" />
    <link rel="canonical" href=" https://www.knightandnoblepublishers.com/KNP-funds" />
    <meta property="og:title" content="Open Access Publication Funds | Funding for Research in UK " />
    <meta property="og:description" content=" Knight and Noble Publishers help researchers to Open Access publication Funds. We provide free Open Access Publication Funds support service to the researchers. " />
    <meta property="og:locale" content="en" />
    <meta property="og:type" content="website" />
    <meta property="og:image" content=" https://www.knightandnoblepublishers.com/images/logo.webp " />
    <meta property="og:image:alt" content=" knightandnoblepublishers.com " />
    <meta property="og:url" content=" https://www.knightandnoblepublishers.com " />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:description" content="Knight and Noble Publishers help researchers to Open Access publication Funds. We provide free Open Access Publication Funds support service to the researchers. " />
    <meta name="twitter:title" content=" Open Access Publication Funds | Funding for Research in UK " />
    <meta name="twitter:site" content="@NoblePublishers" />
    <meta name="twitter:creator" content="@NoblePublishers " />

    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "Organization",
            "name": "Knight & Noble Publishers",
            "alternateName": "Knight and Noble Publishers",
            "url": "https://www.knightandnoblepublishers.com/",
            "logo": "https://www.knightandnoblepublishers.com/images/logo.webp",
            "contactPoint": {
                "@type": "ContactPoint",
                "telephone": "",
                "contactType": "customer service",
                "areaServed": "GB",
                "availableLanguage": "en"
            },
            "sameAs": [
                "https://www.facebook.com/Knight-Noble-Publishers-108940407528534/",
                "https://twitter.com/NoblePublishers",
                "https://www.instagram.com/KnightandNoble/",
                "https://www.youtube.com/channel/UCnzxQQBLmY2klNd6rgewKVQ?view_as=subscriber",
                "https://www.linkedin.com/in/knight-and-noble-publishers-ba704b1b9/",
                "https://www.pinterest.com/KNPhouse/",
                "https://github.com/KNPhouse",
                "https://www.knightandnoblepublishers.com/"
            ]
        }
    </script>
    <script type="application/ld+json">
        {
            "@context": "https://schema.org/",
            "@type": "Product",
            "name": "Knight & Noble Publishers",
            "image": "https://www.knightandnoblepublishers.com/images/logo.webp",
            "description": "Research Publisher in UK is Providing the Reliable Publishing Solution to the Researcher, Universities, Libraries, Authors. Knight & Noble Publisher Solutions",
            "brand": "Knight & Noble Publishers",
            "sku": "KNP",
            "mpn": "KNP",
            "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "5",
                "bestRating": "5",
                "worstRating": "0",
                "ratingCount": "1210",
                "reviewCount": "1210"
            },
            "review": {
                "@type": "Review",
                "name": "John Marshal",
                "reviewBody": "I have never experienced such a quick, reliable, safe, and absolutely professional service before. Keep it up and thank you Knight & Noble Publishers",
                "reviewRating": {
                    "@type": "Rating",
                    "ratingValue": "5",
                    "bestRating": "5",
                    "worstRating": "0"
                },
                "author": {
                    "@type": "Person",
                    "name": "John"
                },
                "publisher": {
                    "@type": "Organization",
                    "name": "Knight & Noble Publishers"
                }
            }
        }
    </script>


    <!-- fav icon -->
    <meta name="google-site-verification" content="MnUGxYXr7ct5OQM2ejqEjGKHA3_wLStL5o4Aid22VNY" />
    <!-- Bootstrap -->
    <link href="assets/google-font/font.css" rel="stylesheet" defer>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" defer>
    <link href="assets/css/offcanvas-menu.min.css" rel="stylesheet" type="text/css">
    <!-- style-css -->
    <link href="assets/css/style.min.css" rel="stylesheet" type="text/css">
    <link href="images/fav.png" rel="shortcut icon" type="image/png">
    <link rel="shortcut icon" href="images/fav.png" type="image/x-icon" defer>
    <link rel="stylesheet" type="text/css" href="assets/css/style_common.css" defer />
    <link rel="stylesheet" type="text/css" href="assets/css/style1.css" defer />
    <link href="assets/css/mystyle.min.css" rel="stylesheet" type="text/css" defer>
    <link href="assets/css/responsive.min.css" rel="stylesheet" type="text/css" defer>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" defer rel="stylesheet" defer>
    <link rel="stylesheet" href="assets/slick/css/slick.min.css" defer />
    <link rel="stylesheet" href="assets/slick/css/slick-theme.min.css" defer />
    <script src='https://www.google.com/recaptcha/api.js' defer></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-181398305-3" defer></script>
    <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'UA-181398305-3');
    </script>

</head>

<body onload="loadSite()" class="homePageThree">
    <!-- start preloader -->
    <!--<div id="preloader">-->
    <!--    <div class="preloader">-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--        <span></span>-->
    <!--    </div> -->
    <!--</div>-->
    <!-- end preloader -->


    <header class="header-section">
        <div class="topper">
            <div class="top-bar">
                <div class="container">
                    <div class="row">

                        <div class="col-md-3 col-xs-4">
                            <a href="https://www.knightandnoblepublishers.com/"> <img draggable="false"
                                    src="images/logo.png" alt="Knight & Noble Publishers"></a>
                        </div>
                        <div class="col-md-5 col-xs-8">
                            <marquee direction="left">
                                Knight and Noble Publishers are available 24/7 to give you live support with exceptional
                                services.
                            </marquee>
                        </div>
                        <div class="col-md-2 top_socialbar">
                            <a href="https://www.linkedin.com/in/knight-and-noble-publishers-ba704b1b9/"><i
                                    class="fab fa-linkedin-in"></i></a>
                            <a href="https://www.facebook.com/Knight-Noble-Publishers-108940407528534/?ref=nf&hc_ref=ARRwEuwDoVRQz26kPDHLj6FqgU5R6d-JbbFBLKWQXvqYVVRkvYIetoj8MA8MvB6Xym0"
                                target="_blank"><i class="fab fa-facebook-f"></i></a>
                            <a href="https://twitter.com/NoblePublishers"><i class="fab fa-twitter"></i></a>
                            <a href="https://www.instagram.com/KnightandNoble/"> <i class="fab fa-instagram"></i></a>
                        </div>
                        <div class="col-md-2 top_socialbar header_ball">
                            <a href="javascript:void[0];" style="color: #252b50;font-size:20px;font-weight: 600;"
                                onclick="openChat()"><i class="far fa-comment"></i>&nbsp;Live Chat</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <style type="text/css">
        .header-section .navbar .navbar-collapse .navbar-nav li .resources {
            min-width: 345px !important;
        }
        </style>

        <nav class="navbar navbar-inverse hidden-sm hidden-xs" id="navbar">
            <div class="container" style="padding-right: 0px;padding-left: 5px;">


                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav" style="display: inline-block;">

                        <li><a href="https://www.knightandnoblepublishers.com/">Home</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="publication.php">Publications</a></li>
                        <li class="dropdown">
                            <a href="service-and-solution.php">Services & Solutions <i class="fa fa-angle-down"
                                    aria-hidden="true"></i></a>
                            <ul class="dropdown-menu">
                                <li class="li1">
                                    <h4><span style="color:#cf1f2a;">Who</span> we are?</h4>
                                    <p>KNP is a global publishing house providing customized solutions to individuals,
                                        academia and corporations. We deliver targeted solutions in research management
                                        and publishing in collaboration with the global scientific community.</p>
                                    <!-- <p>KNP is committed to make research universal, manageable and accessible. With competent analytics, pre-production, production and post-production teams, KNP emphasizes on quality, standardization, creativeness and professionalism to all your research needs.</p> -->
                                </li>
                                <li class="li1">
                                    <ul class="inner-ul">
                                        <li><a href="KNP-edit.php">KNP Edit </a></li>
                                        <li><a href="KNP-review.php">KNP REVIEW </a></li>
                                        <li><a href="KNP-host.php">KNP HOST </a></li>
                                        <li><a href="KNP-manage.php">KNP MANAGE </a></li>

                                    </ul>
                                </li>
                                <li class="li1">
                                    <ul class="inner-ul">
                                        <li><a href="KNP-advertise.php">KNP ADVERTISE </a></li>
                                        <li><a href="KNP-funds.php">KNP FUND </a></li>
                                    </ul>
                                </li>
                                <li class="li1">
                                    <div class="content">
                                        <img src="images/mega1.png" alt="mega 1.4">
                                        <div class="sub">
                                            <h5>Global</h5>
                                            <p>Innovation</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <img src="images/mega2.png" alt="mega 1.3">
                                        <div class="sub">
                                            <h5>Publishing</h5>
                                            <p>Research</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <a href="reviews.php"><button class="btn-review-knp">Reviews</button></a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown ">
                            <a href="resources.php">Resources <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                            <ul class="dropdown-menu resources">
                                <li class="li1">
                                    <h4><span style="color:#cf1f2a;">Who</span> we are?</h4>
                                    <p>KNP is committed to make research universal, manageable and accessible. With
                                        competent analytics, pre-production, production and post-production teams, KNP
                                        emphasizes on quality, standardization, creativeness and professionalism to all
                                        your research needs.</p>
                                </li>
                                <li class="li1">
                                    <ul class="inner-ul" style="padding:10px;">
                                        <li><a href="for-authors.php" onclick="openCity(event, 'Guidelines')">FOR
                                                AUTHORS</a></li>
                                        <li><a href="for-librarians.php">FOR LIBRARIANS </a></li>
                                        <li><a href="for-conference-organizers.php">FOR CONFERENCE ORGANIZERS </a></li>
                                    </ul>
                                <li class="li1">
                                    <ul class="inner-ul">
                                        <li><a href="for-industries-institutions.php">FOR INDUSTRIES & INSTITIUTIONS</a>
                                        </li>
                                        <li><a href="KNP-in-developing-countries.php">KNP IN DEVELOPING COUNTRIES</a>
                                        </li>
                                        <li><a href="funding-opportunities.php">FUNDING OPPORTUNITIES</a></li>
                                    </ul>
                                </li>
                                <li class="li1">
                                    <div class="content">
                                        <img src="images/mega1.png" alt="mega 1 ">
                                        <div class="sub">
                                            <h5>Global</h5>
                                            <p>Innovation</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <img src="images/mega2.png" alt="mega 2 ">
                                        <div class="sub">
                                            <h5>Publishing</h5>
                                            <p>Research</p>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <a href="reviews.php"><button class="btn-review-knp">Reviews</button></a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li><a href="distribution.php">Distribution & Access </a></li>
                        <li><a href="https://blog.knightandnoblepublishers.com/">Blogs</a></li>
                        <li><a href="contact-us.php">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
<link rel="stylesheet" href="assets/css/inner-pages.min.css">

<div id="carouselExampleIndicators" class="carousel slide rlelele" data-ride="carousel" >

    <div class="carousel-inner padding-on-top-g">
        <div class="carousel-item active">
            <img draggable="false" class="d-block w-100" src="images/banner/Fund.jpg" alt=" open access publishing funds " >
        </div>

    </div>

    <div class="container service_solutions_inner_banner">
        <div class="row">
            <h4>KNP FUNDS</h4>
        </div>
    </div>
</div>

<section class="first_fold inside-li">
    <div class="container">
        <div class="row distribution p-0" >


            <div class="col-md-8">
                <h4>KNP FUNDS</h4>
                <p><b>KNP Funds</b> reforms your research program strategy by assisting you find active, accurate
                    funding opportunities in a timely manner from government and private funding organizations, and by
                    offering insight into research that has already been funded in your area of interest.</p>
                <p><b>KNP Funds</b> sources data on active funding opportunities, awarded grants and funder profiles and
                    combines it in such a way that, whatever role you play as an institutional stakeholder, you can
                    apply it directly to your work, responsibilities and workflows. That is why KNP Funds is unique. It
                    is the only solution to provide active, accurate funding information on a wide range of funders,
                    while simultaneously delivering insights into awarded grants.</p>





            </div>
            <div class="col-md-4 service_solution_inner_pages_img">
                <img draggable="false" src="images/distribution_world.png" alt="publication services" >
            </div>
        </div>


        <div class="row distribution p-0" >


            <div class="col-md-12">

                <h5>GENERAL RESOURCES FOR OPEN ACCESS FUNDING</h5>
                <p>The main output of research is new ideas and knowledge, which we expect our researchers to publish as
                    high-quality, peer-reviewed research articles, monographs and book chapters.</p>

                <p>We believe that maximizing the distribution of these publications – by providing free, online access
                    – is the most effective way of ensuring that the research we fund can be accessed, read and built
                    upon. In turn, this will foster a richer research culture.</p>
                <p>In order to support authors, who choose to make their research articles immediately available upon
                    publication, we promote your research work for research funders and institutions worldwide that fund
                    open access article-processing charges. <b>KNP Funds</b> offers a free open access support service
                    to make it easier for our authors to discover and apply for funding to cover article processing
                    charges</p>
                <p>We can provide personalized information on Open-Access funds that may be available to you, direct you
                    to the open access funding coordinator at your institution or funding body. We also supply you with
                    the information required to complete an open access funding application and help you demonstrate the
                    benefits of Open-Access to support your application.</p>



                <p>We offer personalized advice about the application process for your institution or funding body and
                    counsel about compliance with funders' and institutions' Open-Access policies.</p>
            </div>
        </div>
    </div>
</section>

<section class="s-e-o-content">
    <div class="container">
        <div class="content">
            <h1>Get opportunities for Open Access publication Funds </h1>
            <p>Knight and Noble publishers improve your research funding strategies by gaining more Open Access
                publication Funds
                We use guidelines to supports the authors to comply with funders' requirements; Knight and noble
                publishers can help to discover, store, access, manage references for more opportunities to get Open
                Access publication Funds in less time from private funding organizations and government.
            </p>
            <p>Knight and noble publishers <a
                    href="https://www.knightandnoblepublishers.com/funding-opportunities">Open Research Funds in
                    UK</a>offer value to institutions and researchers and the funders by refining the productivity of
                funds for researchers to increase the probability of success. </p>
            <p>Knight and noble publishers help researchers to find Open Access publication Funds by reducing the period
                that is required for the search for gaining more opportunities so that researchers can discover more
                funding for research in UK. </p>
            <h2> Knight and noble funding solutions </h2>
            <p>Improve the process of funding for research and increase the chances of success, we provide help to
                researchers to discover more funders, choose the funding opportunities, polish researchers skills to
                write effective proposals. Help researcher to find funding solutions, help in decision making, as knight
                & noble is the <a href="https://www.knightandnoblepublishers.com/about">Best Publisher in UK</a>.</p>
            <div class="accordion md-accordion" id="accordionEx" role="tablist" aria-multiselectable="true">
                <div class="card2">
                    <div class="card-header" role="tab" id="headingOne1">
                        <a data-toggle="collapse" data-parent="#accordionEx" href="#collapse323" aria-expanded="true"
                            aria-controls="collapse323">
                            <button onclick="myFunct()" id="myBtn">Learn More</button>

                        </a>
                    </div>
                    <!-- Card body -->
                    <div id="collapse323" class="collapse " role="tabpanel" aria-labelledby="headingOne1"
                        data-parent="#accordionEx">
                        <div class="card-body">
                            <h3>How to find opportunities of Open Access publication Funds </h3>
                            <p>Knight and noble publishers’ funds cause information on vigorous funding chances, and
                                researcher can apply it directly for the work. A researcher needs to be flexible and
                                creative in seeking funding and we provide flexible approaches to get the funding for
                                research in UK. Find <a href="https://www.researchgate.net/">scientific experts</a>,
                                they can help for placement by identifying who
                                is suitable for funding on the basis of application and abstract. Look for beneficial
                                discord between funding stream and collaborators, find out who is more active in your
                                research subject.
                                Scientific panel play a part in recommending the experts who are good for the peer
                                review in the specific field and those are who more relevant foe the specific research.
                            </p>
                            <h3>Impactful proposal for funds </h3>
                            <p>A researcher can maximize the probability for funds by making an effective proposal,
                                including grant application summary, overview of your research, problem statement, the
                                aim of the research, design, project evaluation, funding in future, the budget of the
                                project.</p>
                            <p>Research proposal are used to deliver the scope of your research for having the Open
                                Access publication Funds so it needs to be tangible report, efficiently prepared, well
                                planned and completed. </p>
                            <p>Knight and noble publishers promote the research work globally to support the authors who
                                want to get the immediate publication for the research and funding for research in UK.
                            </p>
                            <p>We offer open access services for free to help the authors to find and easily apply for
                                funding to cover article charges. Knight and noble publishers also can provide modified
                                data on open access funds that may available for you, direct you to open funding
                                collaborator at your selected database. Get the information to complete the application
                                process and can help you to describe explain the advantages of open access to support
                                the application. get valuable visions into the process for finding, applying and to
                                secure the funding, researchers should work hard to get the Open Access publication
                                Funds.
                                Research plan is also important it has a contribution to your development as a
                                scientific author, the plan is a shape for your career as a researcher, and you prepare
                                your plan effectively it will get you quick publication.
                            </p>
                            <p>Knight and noble publishers modify your research plan and process by strategizing and
                                assisting you to find the appropriate funding programs in less time from the private and
                                government funding programs, we have simple and beneficial strategies to help you to get
                                the funding for research in UK.</p>


                            <p>The primary object of research is more knowledge and ideas, that we expect our
                                researchers
                                to publish as high quality, monographs, peer reviewed and chapters of books, we highly
                                encouraged to maximizing the disseminating of the publications by giving researchers
                                free,
                                open access, that is smart way of confirming that the research we funded in open access,
                                is
                                accessed read and disseminated globally to spread more knowledge.</p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


 <section class="signup-section">
     <div class="container">
         <div class="row">
             <div class="col-md-6 col-sm-6">
                 <div class="row">
                     <div class="col-md-8 white-123321">
                         <h4><span>Subscribe</span> to our Newsletter</h4>
                         <p>You will recieve emails regarding <br>updated & Promotions </p>
                         <div class="contact-wrapper">
                             <form action="email" method="POST" class="signupForm" id="footer_form">
                                 <span class="contacterr">Please enter email*</span>
                                 <div class="form-wrapper">
                                     <input class="searchBar input1" type="email" name="email" required="required" placeholder="Enter Your Email">
                                     <button type="button" class="subscribeBtn btn-primary onSubmitSingle" data-id="footer_form" data-button-id="recaptcha_callback2"><img width="23px" src="images/email_send.png" alt="email send "></button>
                                     <button class="g-recaptcha" data-sitekey="6LdyGAkdAAAAAOx2NtQtJ-1wH4PkJf4sZGmk_5tP" data-callback="onSubmit2" id="recaptcha_callback2"></button>
                                 </div>
                                 <span class="emailerr">Please type correct email address</span>
                             </form>
                         </div>
                     </div>
                 </div>
             </div>
             <div class="col-md-6 col-sm-6 hidden-xs">
                 <img draggable="false" src="images/newsletter_testimonial.png" class="pad-58" alt="knp testimonial" width="100%">
             </div>
         </div>
     </div>
 </section>
<footer class="footer-section">
    <div class="footer-container">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-12">
                    <div class="footer-wrapper">
                        <a href="https://www.knightandnoblepublishers.com/">
                            <img draggable="false" src="images/footer_logo.png" alt="knp publishers">
                        </a>
                        <p>Knight & Noble Publishers is a global research publisher providing recognition, permanence
                            and solutions to the research community.</p>
                    </div> <!-- footer-wrapper -->
                </div>
                <div class="col-md-9 col-sm-12">
                    <div class="row">
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Quick Links</h4>
                            <ul>
                                <li><a href="https://www.knightandnoblepublishers.com/">Home</a></li>
                                <li><a href="about">About Us</a></li>
                                <li><a href="publication">Publication</a></li>
                                <li><a href="distribution">Distribution & Access</a></li>
                                <li><a href="contact-us">Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Services</h4>
                            <ul>
                                <li><a href="KNP-edit">KNP Edit</a></li>
                                <li><a href="KNP-review">KNP Review</a></li>
                                <li><a href="KNP-host">KNP Host</a></li>
                                <li><a href="KNP-manage">KNP Manage</a></li>
                                <li><a href="KNP-advertise">KNP Advertise</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Resources</h4>
                            <ul>
                                <li><a href="for-authors">For Authors</a></li>
                                <li><a href="for-librarians">Librarians</a></li>
                                <li><a href="for-conference-organizers">Conference Organizers</a></li>
                                <li><a href="for-industries-institutions">For Industries</a></li>
                                <li><a href="funding-opportunities">Funding Opportunities</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-xs-6 col-sm-3">
                            <h4>Legal</h4>
                            <ul>
                                <li><a href="terms">Terms and Conditions</a></li>
                                <li><a href="privacy">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-2 bottom_socialbar">
                    <a href="https://www.linkedin.com/in/knight-and-noble-publishers-ba704b1b9/"><i class="fab fa-linkedin-in"></i></a>
                    <a href="https://www.facebook.com/Knight-Noble-Publishers-108940407528534/?ref=nf&hc_ref=ARRwEuwDoVRQz26kPDHLj6FqgU5R6d-JbbFBLKWQXvqYVVRkvYIetoj8MA8MvB6Xym0" target="_blank"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://twitter.com/NoblePublishers"><i class="fab fa-twitter"></i></a>
                    <a href="https://www.instagram.com/KnightandNoble/"> <i class="fab fa-instagram"></i></a>
                </div>
                <div class="col-md-10">
                    <p><span style="font-weight: 600;">Disclaimer Terms: </span>We use cookies to help provide and
                        enhance our service and tailor content and ads. By continuing you agree to the use of cookies.
                    </p>
                </div>
            </div>
            <div class='row' style="border-top: 1px solid #767676;">
                <p style="margin:0px;text-align: center;color: #cbcbcb;" class="copy-right">Copyright ©
                    2024 <span style="font-weight: 700;">KNP</span> or its licencors or contributors.
                    <span style="font-weight: 700;">Managing Research™</span> is the registered trademark of KNP.
                </p>
            </div>
        </div>
    </div>
</footer>
<!-- Off-Canvas View Only -->
<span class="menu-toggle navbar visible-xs visible-sm"><i class="fa fa-bars" aria-hidden="true"></i></span>
<div id="offcanvas-menu" class="visible-xs visible-sm">
    <span class="close-menu"><i class="fa fa-times" aria-hidden="true"></i></span>
    <ul class="menu-wrapper">
        <li><a href="https://www.knightandnoblepublishers.com/">Home</a></li>
        <li><a href="about">About Us</a></li>
        <li><a href="publication">Publications</a></li>
        <li>
            <!-- class="dropmenu" -->
            <div class="accordion" id="accordionExample">
                <div class="card-header" id="headingOne">
                    <h2 class="m-0">
                        <button class="btn btn-link w-100 collapse-btn" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            <a class="" href="#">Service <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                        </button>
                    </h2>
                </div>
                <div id="collapseOne" class="collapse " aria-labelledby="headingOne" data-parent="#accordionExample">
                    <ul class="dropDown sub-menu display-block">
                        <li><a href="service-and-solution">All Services</a></li>
                        <li><a href="KNP-edit">KNP Edit </a></li>
                        <li><a href="KNP-review">KNP Review </a></li>
                        <li><a href="KNP-host">KNP Host </a></li>
                        <li><a href="KNP-manage">KNP Manage </a></li>
                        <li><a href="KNP-advertise">KNP Advertise </a></li>
                        <li><a href="KNP-funds">KNP Fund </a></li>
                    </ul><!-- end of dropdown -->
                </div>
            </div>
        </li><!-- end of li -->
        <li>
            <div class="accordion" id="accordionExample">
                <div class="card-header" id="headingTwo">
                    <h2 class="m-0">
                        <button class="btn btn-link w-100 collapse-btn" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                            <a class="" href="#">Resources <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                        </button>
                    </h2>
                </div>
                <div id="collapseTwo" class="collapse " aria-labelledby="headingTwo" data-parent="#accordionExample">
                    <ul class="dropDown sub-menu">
                        <li><a href="resources">All Resources</a></li>
                        <li><a href="for-authors" onclick="openCity(event, 'Guidelines')">For Author</a></li>
                        <li><a href="for-librarians">FOR LIBRARIANS </a></li>
                        <li><a href="for-conference-organizers">For Confrence Organizers </a></li>
                        <li><a href="for-industries-institutions">For Industries Institutions</a></li>
                        <li><a href="KNP-in-developing-countries">KNP In Developing Countries</a></li>
                        <li><a href="funding-opportunities">Funding Opportunities</a></li>
                    </ul><!-- end of dropdown -->
                </div>
            </div>
        </li><!-- end of li -->
        <li><a href="distribution">Distribution & Access </a></li>
        <li><a href="https://blog.knightandnoblepublishers.com/">Blogs</a></li>
        <li><a href="contact-us">Contact Us</a></li>
    </ul> <!-- menu-wrapper -->
</div>
<!-- Off-Canvas View Only -->
<div id="toTop" class="hidden-xs">
    <i class="fa fa-chevron-up"></i>
</div> <!-- totop -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/slick.min.js"></script>
<script src="assets/js/script.min.js"></script>
<script type="text/javascript">
    var Tawk_API = Tawk_API || {},
        Tawk_LoadStart = new Date();
    (function() {
        var s1 = document.createElement("script"),
            s0 = document.getElementsByTagName("script")[0];
        s1.async = true;
        s1.src = 'https://embed.tawk.to/6114066e649e0a0a5cd0ad7b/1fcr3i8s5';
        s1.charset = 'UTF-8';
        s1.setAttribute('crossorigin', '*');
        s0.parentNode.insertBefore(s1, s0);
    })();
</script>

<script>
    function onSubmit(token) {
        document.getElementById("contact_form").submit();
    }

    function onSubmit2(token) {
        document.getElementById("footer_form").submit();
    }

    function isEmail(email) {
        var EmailRegex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        return EmailRegex.test(email);
    }
    $(document).ready(function() {
        $('.onSubmit').click(function(e) {
            var empty = true;
            var data_form_id = $(this).attr('data-id');
            var data_button_id = $(this).attr('data-button-id');
            var name = $('#' + data_form_id + ' input[name="name"]').val();
            var email = $('#' + data_form_id + ' input[name="email"]').val();
            var phone = $('#' + data_form_id + ' input[name="phone"]').val();
            if (name == '') {
                empty = false;
                $('#' + data_form_id + ' input[name="name"]').addClass("error");
                $('#' + data_form_id + ' .emailerr').hide();
            } else {
                $('#' + data_form_id + ' input[name="name"]').removeClass("error");
                $('#' + data_form_id + ' .emailerr').hide();
            }
            if (email == '' && phone == '') {
                empty = false;
                $('#' + data_form_id + ' .contacterr').css('display', 'block');
            } else {
                $('#' + data_form_id + ' .contacterr').hide()
                $('#' + data_form_id + ' .emailerr').hide()
                //check email format
                if (email != '') {
                    if (isEmail(email) == false) {
                        empty = false;
                        $('#' + data_form_id + ' .emailerr').css('display', 'block');
                    } else {
                        $('#' + data_form_id + ' .emailerr').hide();
                    }
                }
            }
            if (empty == true) {
                jQuery('#' + data_button_id).click();
            } else {
                return false;
            }
        });
        $('.onSubmitSingle').click(function(e) {
            var empty = true;
            var data_form_id = $(this).attr('data-id');
            var data_button_id = $(this).attr('data-button-id');
            var email = $('#' + data_form_id + ' input[name="email"]').val();
            if (email == '') {
                empty = false;
                $('#' + data_form_id + ' .contacterr').css('display', 'block');
                $('#' + data_form_id + ' .emailerr').hide()

            } else if (email != '') {
                if (isEmail(email) == false) {
                    empty = false;
                    $('#' + data_form_id + ' .emailerr').show();
                    $('#' + data_form_id + ' .contacterr').hide()

                } else {
                    $('#' + data_form_id + ' .emailerr').hide();
                    $('#' + data_form_id + ' .contacterr').hide()
                }
            }
            if (empty == true) {
                jQuery('#' + data_button_id).click();
            } else {
                return false;
            }
        });
    });

    $(document).ready(function() {
        $(window).keydown(function(event) {
            if (event.keyCode == 13) {
                event.preventDefault();
                return false;
            }
        });
    });
</script>
</body>


</html>
